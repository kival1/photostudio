<?php
if (session_status() === PHP_SESSION_NONE){session_start();} 
if(!isset($_SESSION["mobipager"])){
echo "Access Denied";
exit;    
}
function url(){
    if(isset($_SERVER['HTTPS'])){
        $protocol = ($_SERVER['HTTPS'] && $_SERVER['HTTPS'] != "off") ? "https" : "http";
    }
    else{
        $protocol = 'http';
    }
    return $protocol . "://" . parse_url($_SERVER['REQUEST_URI'], PHP_URL_HOST);
}
function path2url($file,$proto) {
    return $proto.$_SERVER['HTTP_HOST'].str_replace($_SERVER['DOCUMENT_ROOT'], '', $file);
}

function rel2abs($rel, $base)
{
    /* return if already absolute URL */
    if (parse_url($rel, PHP_URL_SCHEME) != '') return $rel;

    /* Url begins with // */
    if($rel[0] == '/' && $rel[1] == '/'){
        return 'https:' . $rel;
    }

    /* queries and anchors */
    if ($rel[0]=='#' || $rel[0]=='?') return $base.$rel;

    /* parse base URL and convert to local variables:
       $scheme, $host, $path */
    extract(parse_url($base));

    /* remove non-directory element from path */
    $path = preg_replace('#/[^/]*$#', '', $path);

    /* destroy path if relative url points to root */
    if ($rel[0] == '/') $path = '';

    /* dirty absolute URL */
    $abs = "$host$path/$rel";

    /* replace '//' or '/./' or '/foo/../' with '/' */
    $re = array('#(/\.?/)#', '#/(?!\.\.)[^/]+/\.\./#');
    for($n=1; $n>0; $abs=preg_replace($re, '/', $abs, -1, $n)) {}

    /* absolute URL is ready! */
    return $scheme.'://'.$abs;
}
$fileurl = dirname(path2url($_SERVER['PHP_SELF'], url()))."/";
$url = rel2abs('./images/', $fileurl);
$dir = "./images/";
if(is_dir($dir)){
    if($dh = opendir($dir)){
		$i=1;
        while(($file = readdir($dh)) != false){
            if($file != "." and $file != ".."){
                $files_array[] = array('src' => $url.$file, "title" => "Pic $i"); // Add the file to the array
            }
        $i++;			
        }
		
    }
    $return_array = array("data" => $files_array);
	header('Content-Type: application/json');

echo json_encode($return_array);
exit;

}
?>
