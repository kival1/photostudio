<?php
if (session_status() === PHP_SESSION_NONE){session_start();} 
if(!isset($_SESSION["mobipager"])){
echo "Access Denied";
exit;    
}
// Includs database connection
include "db_connect.php";
if(!empty($_GET["uninstallid"])){
function delTree($dir)
    { 
        $files = array_diff(@scandir($dir), array('.', '..')); 

        foreach (@$files as $file) { 
            (is_dir("$dir/$file")) ? delTree("$dir/$file") : unlink("$dir/$file"); 
        }

        return @rmdir($dir); 
    }
$id = SQLite3::escapeString ($_GET['uninstallid']); // rowid from url
// Prepar the deleting query according to rowid
$query = "DELETE FROM page WHERE rowid=$id";

// Run the query to delete record
if( $db->query($query) or die($db->lastErrorMsg()) ){
	$appfolder = "./plugins/".$_GET['plugin_name']."/";
	$storagefolder = "./storage/".$_GET['plugin_name']."/";
	delTree($appfolder);
	delTree($storagefolder);
	$message = "<div class='text-center py-2 bg-dark text-white'>Plugin has been Uninstalled.</div>";
}else {
	$message = "<div class='text-center py-2 bg-danger text-white'>Sorry, Plugin was not Uninstalled pleases try again later.</div>";
}

}
// Makes query for plugin list
$query = "SELECT * FROM page WHERE pagetype = 'plugin' ";

// Run the query and set query result in $result
// Here $db comes from "db_connection.php"
$result = $db->query($query) or die($db->lastErrorMsg());
?>

<div class='main-container  bg-dark'>
<div class="container-fluid pb-2 pt-2">
<div class="modal-content p-4 pb-4 pt-4">

<div class="border-bottom mb-3 row">
<div class="col text-center"><h4><b>Installed Plugin</b></h4></div>
<div class="col-12 text-center"><?php echo @$message ?></div>
</div>

<div class="formspec">		
		
		<table id="pluginlist" class="table table-bordered table-striped">
			<thead>
			    <th width="10%"  scope="col">Image</th>
				<th width="40%"  scope="col">Plugin Name</th>
				<th width="15%"  scope="col">Version</th>
				<th scope="col">Action</th>
			</thead>
			<?php 
			while($row = $result->fetchArray()) {
				?>
			<tr>
			    <td data-label="Image"><img src="./plugins/<?php echo $row['name'];?>/splash.png" style="height: 50px;max-width: 150px; width: 100%"></td>
				<td data-label="Plugin Name"><?php echo $row['name'];?></td>
				<td data-label="Version">v<?php echo $row['plugincode'];?></td>
				<td data-label="Action" align="middle">
					<a class="btn btn-dark" target="_blank" href="./plugins/<?php echo $row['name'];?>">Dasboard <i class="fa fa-chevron-right"></i></a> | 
					<a class="btn btn-danger" title="Uninstall" href="?page_action=plugins&uninstallid=<?php echo $row['id'];?>&plugin_name=<?php echo $row['name'];?>" onclick="return confirm('Are you sure you want to uninstall this plugin? Executing this action will delete all the resources related this plugin from your server and cannot be undo after execution.');"><i class="fa fa-trash"></i> Uninstall</a>
				</td>
			</tr>
			<?php } 
			?>
		</table>

  </div>
  
   
  </div>	
</div>	
</div>
<script>
$(document).ready( function () {
    var table = $('#pluginlist').DataTable();
});
</script>