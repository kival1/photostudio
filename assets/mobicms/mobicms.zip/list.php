<?php
if(!isset($_SESSION["mobipager"])){
echo "Access Denied";
exit;    
}

// Includs database connection
include "db_connect.php";
// Create Table "page" into Database if not exists 
$query = "CREATE TABLE IF NOT EXISTS page (id INTEGER PRIMARY KEY AUTOINCREMENT, status STRING, name STRING, pagetype STRING, title STRING, description STRING, content TEXT)";
$db->exec($query);
// Makes query with rowid
$query = "SELECT * FROM page WHERE pagetype = 'page' ";

// Run the query and set query result in $result
// Here $db comes from "db_connection.php"
$result = $db->query($query) or die($db->lastErrorMsg());

?>

	<div class='main-container bg-light'>
<div class="container-fluid pb-5 pt-5">
<div class="modal-content p-4 pb-4 pt-4">


<div class="border-bottom mb-3 row">
<div class="col text-center"><h4><b>Pages listing</b></h4></div>
</div>
<div class="formspec">		
		
		<table  class="table table-bordered table-striped">
			<thead>
				<th  scope="col">ID</th>
				<th width="40%"  scope="col">Name</th>
				<th width="30%"  scope="col">Status</th>
				<th  scope="col">Action</th>
			</thead>
			<?php 
			while($row = $result->fetchArray()) {
				?>
			<tr>
				<td data-label="ID"><?php echo $row['id'];?></td>
				<td data-label="Name"><?php echo $row['name'];?></td>
				<td data-label="Status"><?php echo $row['status'];?></td>
				<td data-label="Action">
					<a class="btn btn-dark" href="?page_action=update&id=<?php echo $row['id'];?>"><i class="fa fa-edit"></i> Edit</a> | 
					<a class="btn btn-dark"  href="?page_action=delete&id=<?php echo $row['id'];?>" onclick="return confirm('Are you sure you want to delete this page?');"><i class="fa fa-trash"></i> Delete</a>
				</td>
			</tr>
			<?php } 
			?>
		</table>

  </div>
  
   
  </div>	
</div>	
</div>
