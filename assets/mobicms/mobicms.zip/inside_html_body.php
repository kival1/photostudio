<?php
echo  $includefile;
?>
