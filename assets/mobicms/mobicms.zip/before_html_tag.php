<?php
session_start();
//Includs database connection
require "mobicms/db_connect2.php";
if(isset($_GET["pagename"]) && !empty($_GET["pagename"])){
$pagename = SQLite3::escapeString ($_GET["pagename"]); // rowid from url
// Prepar the query to get the row data with rowid
$query = "SELECT  * FROM page WHERE name= '".$pagename."' AND status = 'active'  LIMIT 1";
$result = $db->query($query);
$data = $result->fetchArray(); // set the row in $data
$title = !empty($data["title"]) ? $data["title"] : "Page Not Found";
$description = !empty($data["description"]) ? $data["description"] : "No Page description  Found";
if(!empty($data["id"])){
$found = "yes";	
$includefile = $data["content"];
}else{
$datacontent = file_get_contents("./mobicms/404.php");
$includefile = $datacontent;	
$found = "no";	
}
}else{
$title = "Content Not Found";
$description = "No Content description  Found";
$found = "no";
$datacontent = file_get_contents("./mobicms/404.php");
$includefile = $datacontent;
}
$db->close();
?>