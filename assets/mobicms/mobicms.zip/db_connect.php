<?php
if (!is_dir("./storage/mobicms/")) {
    mkdir("./storage/mobicms/", 0777, true);
}
if(!file_exists("./storage/mobicms/pages.db")){
// Database name
$database_name = "./storage/mobicms/pages.db";
// Database Connection
$db = new SQLite3($database_name);
// Create Table "students" into Database if not exists 
$query = "CREATE TABLE IF NOT EXISTS page (id INTEGER PRIMARY KEY AUTOINCREMENT, status STRING, name STRING, pagetype STRING, plugintype STRING, plugincode STRING, title STRING, description STRING, content TEXT)";
$db->exec($query);
$query2 = "INSERT INTO page (status, name, title, pagetype, plugintype, plugincode, description, content) VALUES ('Active', 'usermanager', 'Mobicms Usermanager Basic', 'plugin', 'application', '1.2.0', 'This plugin enable mobirise users integrate a complete management system namely: login,signup and reset password on their website', '')";	
$db->exec($query2);
}else{
// Database name
$database_name = "./storage/mobicms/pages.db";

// Database Connection
$db = new SQLite3($database_name);

// Create Table "students" into Database if not exists 
$query = "CREATE TABLE IF NOT EXISTS page (id INTEGER PRIMARY KEY AUTOINCREMENT, status STRING, name STRING, pagetype STRING, plugintype STRING, plugincode STRING, title STRING, description STRING, content TEXT)";
$db->exec($query);
}


?>