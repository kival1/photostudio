/*! summernote-classes v0.2 + includes Bootstrap 5 sample classes */
(function (factory) {
  if (typeof define === 'function' && define.amd) {
    define(['jquery'], factory);
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(require('jquery'));
  } else {
    factory(window.jQuery);
  }
}
(function ($) {
var version = 4;
  $.extend(true, $.summernote.lang, {
	  'en-US': {
      classes: {
		h1: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'Bolder', 'Bold', 'Italic'],
		h2: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'Bolder', 'Bold', 'Italic'],
		h3: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'Bolder', 'Bold', 'Italic'],
		h4: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'Bolder', 'Bold', 'Italic'],
		h5: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'Bolder', 'Bold', 'Italic'],
		h6: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'Bolder', 'Bold', 'Italic'],
		td: [ 'Text', 'Menu', 'Bolder', 'Bold', 'Italic', 'White text'],
		code: [ 'Text', 'Menu', 'Bolder', 'Bold', 'Italic'],
        li: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'list-group-item', 'active', 'success', 'secondary', 'info', 'warning', 'danger', 'dark', 'light'],
		a: [ 'button', 'link', 'primary', 'secondary', 'danger', 'info', 'dark', 'float-left', 'float-center', 'float-right', 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu'],
        img: [ 'responsive', 'float-left', 'float-center', 'float-right', 'rounded', 'circle', 'small-shadow', 'shadow', 'large-shadow', 'thumbnail', '100%  width', '75%  width', '50%  width', '25%  width','auto width','100% height'],
        p: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'Bolder', 'Bold', 'Italic', 'Primary', 'Secondary',  'Danger',  'Success',   'Info', 'Center', 'Right', 'Left', 'Wrap', 'No-wrap', 'Truncate', 'Break', 'Lowercase', 'Uppercase', 'Capitalize', 'Monospace', 'lead', 'muted'],
		u: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'Bolder', 'Bold', 'Italic', 'Primary', 'Secondary',  'Danger',  'Success',   'Info', 'Center', 'Right', 'Left', 'Wrap', 'No-wrap', 'Truncate', 'Break', 'Lowercase', 'Uppercase', 'Capitalize', 'Monospace', 'lead', 'muted'],
		b: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'Bolder', 'Bold', 'Italic', 'Primary', 'Secondary',  'Danger',  'Success',   'Info', 'Center', 'Right', 'Left', 'Wrap', 'No-wrap', 'Truncate', 'Break', 'Lowercase', 'Uppercase', 'Capitalize', 'Monospace', 'lead', 'muted'],
		span: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'Bolder', 'Bold', 'Italic', 'Primary', 'Secondary',  'Danger',  'Success',   'Info',  'Wrap', 'No-wrap', 'Truncate', 'Lowercase', 'Uppercase', 'Capitalize', 'muted'],
		
      }
    }  
  });
  $.extend($.summernote.options, {
    disableTableNesting: false,
      classes: {
		h1: ['display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'fw-bolder', 'fw-bold','fst-italic'],
		h2: ['display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'fw-bolder', 'fw-bold','fst-italic'],
		h3: ['display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'fw-bolder', 'fw-bold','fst-italic'],
		h4: ['display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'fw-bolder', 'fw-bold','fst-italic'],
		h5: ['display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'fw-bolder', 'fw-bold','fst-italic'],
		h6: ['display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'fw-bolder', 'fw-bold','fst-italic'],
		td: ['Text', 'Menu', 'fw-bolder', 'fw-bold', 'fst-italic', 'text-white'],
		code: ['Text', 'Menu', 'fw-bolder', 'fw-bold', 'fst-italic'],
        li: [ 'display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'list-group-item', 'active', 'text-success', 'text-secondary', 'text-info', 'text-warning', 'text-danger', 'text-dark', 'text-light'],
		a: [ 'btn', 'link', 'btn-primary', 'btn-secondary', 'btn-danger', 'btn-info', 'btn-dark', 'float-start', 'float-center', 'float-end', 'display-1', 'display-2', 'display-3', 'display-7', 'display-4',],
        img: [ 'img-fluid', 'float-start', 'mx-auto d-block', 'float-end', 'rounded', 'rounded-circle', 'small-shadow', 'shadow', 'large-shadow', 'img-thumbnail', 'w-100', 'w-75', 'w-50', 'w-25','w-auto','h-100'],
        p: [ 'display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'fw-bolder', 'fw-bold','fst-italic', 'text-primary', 'text-secondary',  'text-danger',  'text-success',   'text-info', 'text-center', 'text-end', 'text-start', 'text-wrap', 'text-nowrap', 'text-truncate', 'text-break', 'text-lowercase', 'text-uppercase', 'text-capitalize', 'text-monospace', 'lead', 'text-muted'],
		u: [ 'display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'fw-bolder', 'fw-bold','fst-italic', 'text-primary', 'text-secondary',  'text-danger',  'text-success',   'text-info', 'text-center', 'text-end', 'text-start', 'text-wrap', 'text-nowrap', 'text-truncate', 'text-break', 'text-lowercase', 'text-uppercase', 'text-capitalize', 'text-monospace', 'lead', 'text-muted'],
		b: [ 'display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'fw-bolder', 'fw-bold','fst-italic', 'text-primary', 'text-secondary',  'text-danger',  'text-success',   'text-info', 'text-center', 'text-end', 'text-start', 'text-wrap', 'text-nowrap', 'text-truncate', 'text-break', 'text-lowercase', 'text-uppercase', 'text-capitalize', 'text-monospace', 'lead', 'text-muted'],
		span: [ 'display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'fw-bolder', 'fw-bold','fst-italic', 'text-primary', 'text-secondary',  'text-danger',  'text-success',  'text-info', 'text-wrap', 'text-nowrap', 'text-truncate', 'text-lowercase', 'text-uppercase', 'text-capitalize', 'text-muted'],
		
      }
  });
  $.extend($.summernote.plugins, {
    'classes': function (context) {
      var self = this,
            ui = $.summernote.ui,
         $note = context.layoutInfo.note,
       $editor = context.layoutInfo.editor,
       $editable = context.layoutInfo.editable,
       options = context.options,
          lang = options.langInfo;
      $("head").append('<style>@media all{.note-classes{color:#888;font-weight:400;cursor:pointer;}.note-classes-active{color:#4c4;font-weight:700;}.note-status-output{height:auto!important;}}</style>');
      this.events = {
        'summernote.mousedown': function (we,e) {
          e.stopPropagation();
          var el = e.target;
          var elem = $(":focus");
          var outputText='';
          if (options.disableTableNesting === true) {
            $('.note-toolbar [aria-label="Table"]').prop('disabled', false);
          }
          if (!el.classList.contains('note-editable')) {
            if (options.disableTableNesting === true) {
              if (el.nodeName == 'TD') {
                $('.note-toolbar [aria-label="Table"]').prop('disabled', true);
              }
            }
            outputText += el.nodeName;
            var nN=el.nodeName.toLowerCase();
            if(nN in options.classes) {
              outputText += ' class=&quot;';
              var nNc=options.classes[nN];
              $.each(nNc, function (index, value){
                if(el.classList.contains(options.classes[nN][index])){
                  outputText += '<span class="note-classes note-classes-active"';
                } else {
                  outputText += '<span class="note-classes"';
                }
                outputText += ' data-class="' + options.classes[nN][index] + '"';
                outputText += '>' + lang.classes[nN][index] + ' </span>';
              });
              outputText += '&quot;';
            }
            $editor.find('.note-status-output').html(outputText);
            $('.note-classes').on('click', function(){
              $(this).toggleClass('note-classes-active');
              var classes=$(this).data('class');
              $(el).toggleClass(classes);
            });
          } else if (el.classList.contains('note-editable')) {
            $editor.find('.note-status-output').html('');
          }
        },
        'summernote.codeview.toggled': function (we,e) {
          $editor.find('.note-status-output').html('');
        }
      }
    }
  });
}));