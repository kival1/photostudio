/*! summernote-classes v0.2 + includes Bootstrap 4 sample classes */
(function (factory) {
  if (typeof define === 'function' && define.amd) {
    define(['jquery'], factory);
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(require('jquery'));
  } else {
    factory(window.jQuery);
  }
}
(function ($) {
var version = 4;
  $.extend(true, $.summernote.lang, {
    'en-US': {
      classes: {
		h1: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'Bold', 'Italic'],
		h2: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'Bold', 'Italic'],
		h3: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'Bold', 'Italic'],
		h4: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'Bold', 'Italic'],
		h5: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'Bold', 'Italic'],
		h6: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'Bold', 'Italic'],
		td: [ 'Text', 'Menu', 'Bold', 'Italic', 'White text'],
		code: [ 'Text', 'Menu', 'Bold', 'Italic'],
        li: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'list-group-item', 'active', 'success', 'secondary', 'info', 'warning', 'danger', 'dark', 'light'],
		a: [ 'button', 'link', 'primary', 'secondary', 'danger', 'info', 'dark', 'float-left', 'float-center', 'float-right', 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu'],
        img: [ 'responsive', 'float-left', 'float-center', 'float-right', 'rounded', 'circle', 'small-shadow', 'shadow', 'large-shadow', 'thumbnail', '100%  width', '75%  width', '50%  width', '25%  width','auto width','100% height'],
        p: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'Primary', 'Secondary',  'Danger',  'Success',   'Info', 'Center', 'Right', 'justify', 'Wrap', 'Nowrap', 'Truncate', 'Break', 'Lowercase', 'Uppercase', 'Capitalization', 'Monospace', 'Lead', 'Border', 'Muted', 'Bold', 'Italic', 'Light'],
		u: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'Primary', 'Secondary',  'Danger',  'Success',   'Info', 'Center', 'Right', 'justify', 'Wrap', 'Nowrap', 'Truncate', 'Break', 'Lowercase', 'Uppercase', 'Capitalization', 'Monospace', 'Lead', 'Border', 'Muted', 'Bold', 'Italic', 'Light'],
		b: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'Primary', 'Secondary',  'Danger',  'Success',   'Info', 'Center', 'Right', 'justify', 'Wrap', 'Nowrap', 'Truncate', 'Break', 'Lowercase', 'Uppercase', 'Capitalization', 'Monospace', 'Lead', 'Border', 'Muted', 'Bold', 'Italic', 'Light'],
		span: [ 'Title 1', 'Title 2', 'Title 3', 'Text', 'Menu', 'Primary', 'Secondary',  'Danger',  'Success',   'infO', 'Wrap', 'Nowrap', 'Truncate', 'Break', 'Lowercase', 'Uppercase', 'Capitalization', 'Monospace', 'Lead', 'Border', 'Muted', 'Bold', 'Italic', 'Light'],
      
      }
    }
	
  });
  $.extend($.summernote.options, {
    disableTableNesting: false,
    classes: {
	  h1: ['display-1', 'display-2', 'display-3', 'display-7', 'display-4',  'font-weight-bold', 'font-italic'],
	  h2: ['display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'font-weight-bold', 'font-italic'],
	  h3: ['display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'font-weight-bold', 'font-italic'],
	  h4: ['display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'font-weight-bold', 'font-italic'],
	  h5: ['display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'font-weight-bold','font-italic'],
	  h6: ['display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'font-weight-bold','font-italic'],
	  td: ['Text', 'Menu', 'font-weight-bold', 'font-italic', 'text-white'],
	  code: ['Text', 'Menu', 'font-weight-bold', 'font-italic'],
	  li: [ 'display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'list-group-item', 'active', 'text-success', 'text-secondary', 'text-info', 'text-warning', 'text-danger', 'text-dark', 'text-light'],
      a: [ 'btn', 'link', 'btn-primary', 'btn-secondary', 'btn-danger', 'btn-info', 'btn-dark', 'float-left', 'float-center', 'float-right', 'display-1', 'display-2', 'display-3', 'display-7', 'display-4',],
      img: [ 'img-fluid', 'float-left', 'mx-auto d-block', 'float-right', 'rounded', 'rounded-circle', 'shadow-sm', 'shadow' ,'shadow-lg' ,'img-thumbnail' ,'w-100', 'w-75', 'w-50', 'w-25', 'w-auto', 'h-100'],
      p: [ 'display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'text-primary', 'text-secondary',  'text-danger',  'text-success',   'text-info', 'text-center', 'text-right', 'text-justify', 'text-wrap', 'text-nowrap', 'text-truncate', 'text-break', 'text-lowercase', 'text-uppercase', 'text-capitalize', 'text-monospace', 'lead', 'border', 'text-muted', 'font-weight-bold', 'font-italic', 'font-weight-light'],
	  u: [ 'display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'text-primary', 'text-secondary',  'text-danger',  'text-success',   'text-info', 'text-center', 'text-right', 'text-justify', 'text-wrap', 'text-nowrap', 'text-truncate', 'text-break', 'text-lowercase', 'text-uppercase', 'text-capitalize', 'text-monospace', 'lead', 'border', 'text-muted', 'font-weight-bold', 'font-italic', 'font-weight-light'],
	  b: [ 'display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'text-primary', 'text-secondary',  'text-danger',  'text-success',   'text-info', 'text-center', 'text-right', 'text-justify', 'text-wrap', 'text-nowrap', 'text-truncate', 'text-break', 'text-lowercase', 'text-uppercase', 'text-capitalize', 'text-monospace', 'lead', 'border', 'text-muted', 'font-weight-bold', 'font-italic', 'font-weight-light'],
	  span: ['display-1', 'display-2', 'display-3', 'display-7', 'display-4', 'text-primary', 'text-secondary',  'text-danger',  'text-success',   'text-info', 'text-wrap', 'text-nowrap', 'text-truncate', 'text-break', 'text-lowercase', 'text-uppercase', 'text-capitalize', 'text-monospace', 'lead', 'border', 'text-muted', 'font-weight-bold', 'font-italic', 'font-weight-light'],
      }
  });
  $.extend($.summernote.plugins, {
    'classes': function (context) {
      var self = this,
            ui = $.summernote.ui,
         $note = context.layoutInfo.note,
       $editor = context.layoutInfo.editor,
       $editable = context.layoutInfo.editable,
       options = context.options,
          lang = options.langInfo;
      $("head").append('<style>@media all{.note-classes{color:#888;font-weight:400;cursor:pointer;}.note-classes-active{color:#4c4;font-weight:700;}.note-status-output{height:auto!important;}}</style>');
      this.events = {
        'summernote.mousedown': function (we,e) {
          e.stopPropagation();
          var el = e.target;
          var elem = $(":focus");
          var outputText='';
          if (options.disableTableNesting === true) {
            $('.note-toolbar [aria-label="Table"]').prop('disabled', false);
          }
          if (!el.classList.contains('note-editable')) {
            if (options.disableTableNesting === true) {
              if (el.nodeName == 'TD') {
                $('.note-toolbar [aria-label="Table"]').prop('disabled', true);
              }
            }
            outputText += el.nodeName;
            var nN=el.nodeName.toLowerCase();
            if(nN in options.classes) {
              outputText += ' class=&quot;';
              var nNc=options.classes[nN];
              $.each(nNc, function (index, value){
                if(el.classList.contains(options.classes[nN][index])){
                  outputText += '<span class="note-classes note-classes-active"';
                } else {
                  outputText += '<span class="note-classes"';
                }
                outputText += ' data-class="' + options.classes[nN][index] + '"';
                outputText += '>' + lang.classes[nN][index] + ' </span>';
              });
              outputText += '&quot;';
            }
            $editor.find('.note-status-output').html(outputText);
            $('.note-classes').on('click', function(){
              $(this).toggleClass('note-classes-active');
              var classes=$(this).data('class');
              $(el).toggleClass(classes);
            });
          } else if (el.classList.contains('note-editable')) {
            $editor.find('.note-status-output').html('');
          }
        },
        'summernote.codeview.toggled': function (we,e) {
          $editor.find('.note-status-output').html('');
        }
      }
    }
  });
}));