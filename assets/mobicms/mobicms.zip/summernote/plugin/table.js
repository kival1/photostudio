(function (factory) {
    /* global define */
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['jquery'], factory);
    } else if (typeof module === 'object' && module.exports) {
        // Node/CommonJS
        module.exports = factory(require('jquery'));
    } else {
        // Browser globals
        factory(window.jQuery);
    }
}(function ($) {

    // Extends plugins for emoji plugin.
    $.extend($.summernote.plugins, {

        'tableHeaders': function (context) {
            var self = this,
                ui = $.summernote.ui,
                options = context.options,
                $editor   = context.layoutInfo.editor,
                $editable = context.layoutInfo.editable;

            context.memo('button.tableHeaders', function () {
                return ui.buttonGroup([
                    ui.button({
                        contents: '<b>H<b>', //ui.icon(options.icons.bold),
                        tooltip:  'Toggle table header',
                        click:function (e) {
                            self.toggleTableHeader();
                        }
                    }),
                ]).render();
            });

            this.toggleTableHeader = function () {
              const rng = context.invoke('createRange', $editable);
              const dom = $.summernote.dom;
              if (rng.isCollapsed() && rng.isOnCell()) {
                context.invoke('beforeCommand');
                var table = dom.ancestor(rng.commonAncestor(), dom.isTable)
                var $table = $(table);
                var $thead = $table.find('thead');
                if ($thead[0]) {
                  // thead found, so convert to a regular row.  When a header
                  // exists and user tries to add a new row below
                  // the header, Summernote actually adds another tr within the
                  // thead so need to capture all and move them into tbody
                  if(self.observer)
                     self.observer.disconnect(); // see below
                  self.replaceTags($thead.find('th'), 'td')
                  var $theadRows = $thead.find('tr');
                  $table.prepend($theadRows);
                  $thead.remove();
                }
                else { // thead not found, so convert top row to header row
                  var $topRow = $table.find('tr')[0];
                  $topRow.remove();

                  var $thead = $("<thead>");
                  $thead.prependTo($table);
                  $thead.append($topRow);
                  self.replaceTags($thead.find('td'), 'th')

                  // Detect changes to the table dom so we can fix the header
                  // after rows or cols are added.  Summernote creates td's only

                  // https://developer.mozilla.org/en-US/docs/Web/API/MutationObserver

                  // Options for the observer (which mutations to observe)
                  var config = { childList: true, subtree: true };
                  // Callback function to execute when mutations are observed
                  var callback = function(mutationsList) {
                    for(var mutation of mutationsList) {
                      self.replaceTags($(mutation.target).find('td'), 'th')
                    }
                  };
                  // Create an observer instance linked to the callback function
                  self.observer = new MutationObserver(callback);
                  // Start observing the target node for configured mutations
                  self.observer.observe($thead[0], config);

                  self.destroy = function () {
                    self.observer.disconnect();
                  };

                } // else

                context.invoke('afterCommand');
              }
            };

            this.replaceTags = function($nodes, newTag) {
              $nodes.replaceWith(function() {
                return $("<" + newTag + " />", {html: $(this).html()});
              });
            }

        }
    });
}));

/* https://github.com/tylerecouture/summernote-lists  */

(function (factory) {
  /* global define */
  if (typeof define === "function" && define.amd) {
    // AMD. Register as an anonymous module.
    define(["jquery"], factory);
  } else if (typeof module === "object" && module.exports) {
    // Node/CommonJS
    module.exports = factory(require("jquery"));
  } else {
    // Browser globals
    factory(window.jQuery);
  }
})(function ($) {
  $.extend(true, $.summernote.lang, {
    "en-US": {
      tableStyles: {
        tooltip: "Table style",
        stylesExclusive: ["Basic", "Bordered"],
        stylesInclusive: [ "Striped", "Responsive", "Condensed", "Hoverable", "Primary", "Secondary", "Success", "Danger", "Info", "Dark"]
      }
    }
  });
  $.extend($.summernote.options, {
    tableStyles: {
      // Must keep the same order as in lang.tableStyles.styles*
      stylesExclusive: ["", "table-bordered"],
      stylesInclusive: ["table-striped", "table-responsive", "table-condensed", "table-hover", "table-primary", "table-secondary", "table-success", "table-danger", "table-info", "table-dark"]
    }
  });

  // Extends plugins for emoji plugin.
  $.extend($.summernote.plugins, {
    tableStyles: function (context) {
      var self = this,
        ui = $.summernote.ui,
        options = context.options,
        lang = options.langInfo,
        $editor = context.layoutInfo.editor,
        $editable = context.layoutInfo.editable,
        editable = $editable[0];

      context.memo("button.tableStyles", function () {
        var button = ui.buttonGroup([
          ui.button({
            className: "dropdown-toggle",
            contents: ui.dropdownButtonContents(
              ui.icon(options.icons.magic),
              options
            ),
            tooltip: lang.tableStyles.tooltip,
            data: {
              toggle: "dropdown"
            },
            callback: function ($dropdownBtn) {
              $dropdownBtn.click(function () {
                self.updateTableMenuState($dropdownBtn);
              });
            }
          }),
          ui.dropdownCheck({
            className: "dropdown-table-style",
            checkClassName: options.icons.menuCheck,
            items: self.generateListItems(
              options.tableStyles.stylesExclusive,
              lang.tableStyles.stylesExclusive,
              options.tableStyles.stylesInclusive,
              lang.tableStyles.stylesInclusive
            ),
            callback: function ($dropdown) {
              $dropdown.find("a").each(function () {
                $(this).click(function (e) {
                  self.updateTableStyles(this);
                  e.preventDefault();
                });
              });
            }
          })
        ]);
        return button.render();
      });

      self.updateTableStyles = function (chosenItem) {
        const rng = context.invoke("createRange", $editable);
        const dom = $.summernote.dom;
        if (rng.isCollapsed() && rng.isOnCell()) {
          context.invoke("beforeCommand");
          var table = dom.ancestor(rng.commonAncestor(), dom.isTable);
          self.updateStyles(
            $(table),
            chosenItem,
            options.tableStyles.stylesExclusive
          );
        }
      };

      /* Makes sure the check marks are on the currently applied styles */
      self.updateTableMenuState = function ($dropdownButton) {
        const rng = context.invoke("createRange", $editable);
        const dom = $.summernote.dom;
        if (rng.isCollapsed() && rng.isOnCell()) {
          var $table = $(dom.ancestor(rng.commonAncestor(), dom.isTable));
          var $listItems = $dropdownButton.parent().find(".dropdown-menu a");
          self.updateMenuState(
            $table,
            $listItems,
            options.tableStyles.stylesExclusive
          );
        }
      };

      /* The following functions might be turnkey in other menu lists
            with exclusive and inclusive items that toggle CSS classes. */

      self.updateMenuState = function ($node, $listItems, exclusiveStyles) {
        var hasAnExclusiveStyle = false;
        console.log($listItems)
        $listItems.each(function () {
          var cssClass = $(this).data("value");
          if ($node.hasClass(cssClass)) {
            $(this).addClass("checked");
            if ($.inArray(cssClass, exclusiveStyles) != -1) {
              hasAnExclusiveStyle = true;
            }
          } else {
            $(this).removeClass("checked");
          }
        });

        // if none of the exclusive styles are checked, then check a blank
        if (!hasAnExclusiveStyle) {
          $listItems.filter('[data-value=""]').addClass("checked");
        }
      };

      self.updateStyles = function ($node, chosenItem, exclusiveStyles) {
        var cssClass = $(chosenItem).data("value");
        context.invoke("beforeCommand");
        // Exclusive class: only one can be applied one at a time
        if ($.inArray(cssClass, exclusiveStyles) != -1) {
          $node.removeClass(exclusiveStyles.join(" "));
          $node.addClass(cssClass);
        } else {
          // Inclusive classes: multiple are ok
          $node.toggleClass(cssClass);
        }
        context.invoke("afterCommand");
      };

      self.generateListItems = function (
        exclusiveStyles,
        exclusiveLabels,
        inclusiveStyles,
        inclusiveLabels
      ) {
        var index = 0;
        var list = "";

        for (const style of exclusiveStyles) {
          list += self.getListItem(style, exclusiveLabels[index], true);
          index++;
        }
        list += '<hr style="margin: 5px 0px">';
        index = 0;
        for (const style of inclusiveStyles) {
          list += self.getListItem(style, inclusiveLabels[index], false);
          index++;
        }
        return list;
      };

      self.getListItem = function (
        value,
        label,
        isExclusive,
      ) {
        var item =
          '<li class="list-group-item"><a href="#" class="' +
          (isExclusive ? "exclusive-item" : "inclusive-item") +
          '" ' +
          'style="display: block;" data-value="' +
          value +
          '">' +
          '<i class="note-icon-menu-check" ' +
          (!isExclusive ? 'style="color:#00ffc0;" ' : "") +
          "></i>" +
          " " +
          label +
          "</a></li>";
        return item;
      };
    }
  });
});
