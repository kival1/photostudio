<?php
//start session to enable session for plugin and pages
session_start();
//Includs database connection
require_once("db_connect.php");
if(isset($_GET["pagename"]) && !empty($_GET["pagename"])){
$pagename = htmlspecialchars($_GET["pagename"]);
$pagename = SQLite3::escapeString($pagename); // rowid from url
// Prepar the query to get the row data with pagename
$query = "SELECT * FROM page WHERE name = '".$pagename."' AND status = 'active' LIMIT 1";
$result = $db->query($query);
$data = $result->fetchArray(); // set the row in $data
$title = !empty($data["title"]) ? $data["title"] : "Page Not Found";
$description = !empty($data["description"]) ? $data["description"] : "No Page description  Found";
$contentname = !empty($data["name"]) ? $data["name"] : "Page Not Found";
if(!empty($data["id"])){
echo  $data["content"];
exit;	
}else{
include "404.php";	
exit;	
}
}else{
include "404.php";	
exit;
}

?>