<?php
session_start();
if(@$_POST["action"] == "install"){
define('ROOTDIR', dirname(__FILE__));
define('LIBDIR', ROOTDIR);
define('CONFIG_FILE', './mobipager.php');

define('CE_NEWLINE', "\r\n");
define('CE_WORDWRAP', 60);
require_once(LIBDIR.'/confedit.class.php');

// Creating an instance of ConfigEditor
$config = new ConfigEditor();

    $config->SetVar('email', $_POST["email"], 'Email to login to MobiPager Dashboard');
	$config->SetVar('password', $_POST["password"], 'Password to login to MobiPager Dashboard');
	$config->Save(CONFIG_FILE);
    file_put_contents("./config.lock", "locked");  
}  

if(@$_POST["action"] == "login"){
	
require_once("./mobipager.php");
if(!empty($_POST["email"]) && !empty($_POST["password"])){
if($_POST["email"] == $email && $_POST["password"] == $password){
$_SESSION["mobipager"] = $_POST["email"];
$_SESSION["version"] = $_POST["version"];
header('Location: ./index.php');
exit;
}else{
$error	= "<div class='bg-danger text-white p-3'>Invalid Login Information</div>";	
}		
}	

}
?>
<!doctype html>
<html>
<head>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<title>Mobicms - Admin Backend</title>
<link href='https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css' rel='stylesheet'>
<link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css' rel='stylesheet'>
<link href='./css/login.css' rel='stylesheet'>
<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
<script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>
<script type='text/javascript' src='https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js'></script>
<link rel="shortcut icon" href="src/images/logo.png" type="image/x-icon">
</head>
<body oncontextmenu='return false' class='bg-dark'>
    <div class="container-fluid">
    <div class="row">
<div class="col d-flex justify-content-center text-white">
    <div class="card2 text-center">
	  Change language
	  <div class="container">
       <!-- GTranslate: https://gtranslate.io/ -->
<a href="#" onclick="doGTranslate('en|nl');return false;" title="Dutch" class="gflag nturl" style="background-position:-0px -100px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="Dutch" /></a><a href="#" onclick="doGTranslate('en|en');return false;" title="English" class="gflag nturl" style="background-position:-0px -0px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="English" /></a><a href="#" onclick="doGTranslate('en|fr');return false;" title="French" class="gflag nturl" style="background-position:-200px -100px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="French" /></a><a href="#" onclick="doGTranslate('en|de');return false;" title="German" class="gflag nturl" style="background-position:-300px -100px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="German" /></a><a href="#" onclick="doGTranslate('en|it');return false;" title="Italian" class="gflag nturl" style="background-position:-600px -100px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="Italian" /></a><a href="#" onclick="doGTranslate('en|pt');return false;" title="Portuguese" class="gflag nturl" style="background-position:-300px -200px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="Portuguese" /></a><a href="#" onclick="doGTranslate('en|ru');return false;" title="Russian" class="gflag nturl" style="background-position:-500px -200px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="Russian" /></a><a href="#" onclick="doGTranslate('en|es');return false;" title="Spanish" class="gflag nturl" style="background-position:-600px -200px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="Spanish" /></a>
</div>

<style type="text/css">
<!--
a.gflag {vertical-align:middle;font-size:16px;padding:1px 0;background-repeat:no-repeat;background-image:url(//gtranslate.net/flags/16.png);}
a.gflag img {border:0;}
a.gflag:hover {background-image:url(//gtranslate.net/flags/16a.png);}
#goog-gt-tt {display:none !important;}
.goog-te-banner-frame {display:none !important;}
.goog-te-menu-value:hover {text-decoration:none !important;}
body {top:0 !important;}
#google_translate_element2 {display:none!important;}
-->
</style>

<select class="form-control" onchange="doGTranslate(this);"><option value="">Select Language</option><option value="en|af">Afrikaans</option><option value="en|sq">Albanian</option><option value="en|ar">Arabic</option><option value="en|hy">Armenian</option><option value="en|az">Azerbaijani</option><option value="en|eu">Basque</option><option value="en|be">Belarusian</option><option value="en|bg">Bulgarian</option><option value="en|ca">Catalan</option><option value="en|zh-CN">Chinese (Simplified)</option><option value="en|zh-TW">Chinese (Traditional)</option><option value="en|hr">Croatian</option><option value="en|cs">Czech</option><option value="en|da">Danish</option><option value="en|nl">Dutch</option><option value="en|en">English</option><option value="en|et">Estonian</option><option value="en|tl">Filipino</option><option value="en|fi">Finnish</option><option value="en|fr">French</option><option value="en|de">German</option><option value="en|el">Greek</option><option value="en|ht">Haitian Creole</option><option value="en|iw">Hebrew</option><option value="en|hi">Hindi</option><option value="en|hu">Hungarian</option><option value="en|is">Icelandic</option><option value="en|id">Indonesian</option><option value="en|ga">Irish</option><option value="en|it">Italian</option><option value="en|ja">Japanese</option><option value="en|ko">Korean</option><option value="en|lv">Latvian</option><option value="en|lt">Lithuanian</option><option value="en|mk">Macedonian</option><option value="en|ms">Malay</option><option value="en|mt">Maltese</option><option value="en|no">Norwegian</option><option value="en|fa">Persian</option><option value="en|pl">Polish</option><option value="en|pt">Portuguese</option><option value="en|ro">Romanian</option><option value="en|ru">Russian</option><option value="en|sr">Serbian</option><option value="en|sk">Slovak</option><option value="en|sl">Slovenian</option><option value="en|es">Spanish</option><option value="en|sw">Swahili</option><option value="en|sv">Swedish</option><option value="en|th">Thai</option><option value="en|tr">Turkish</option><option value="en|uk">Ukrainian</option><option value="en|vi">Vietnamese</option></select><div id="google_translate_element2"></div>
<script type="text/javascript">
function googleTranslateElementInit2() {new google.translate.TranslateElement({pageLanguage: 'en',autoDisplay: false}, 'google_translate_element2');}
</script><script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2"></script>


<script type="text/javascript">
/* <![CDATA[ */
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('6 7(a,b){n{4(2.9){3 c=2.9("o");c.p(b,f,f);a.q(c)}g{3 c=2.r();a.s(\'t\'+b,c)}}u(e){}}6 h(a){4(a.8)a=a.8;4(a==\'\')v;3 b=a.w(\'|\')[1];3 c;3 d=2.x(\'y\');z(3 i=0;i<d.5;i++)4(d[i].A==\'B-C-D\')c=d[i];4(2.j(\'k\')==E||2.j(\'k\').l.5==0||c.5==0||c.l.5==0){F(6(){h(a)},G)}g{c.8=b;7(c,\'m\');7(c,\'m\')}}',43,43,'||document|var|if|length|function|GTranslateFireEvent|value|createEvent||||||true|else|doGTranslate||getElementById|google_translate_element2|innerHTML|change|try|HTMLEvents|initEvent|dispatchEvent|createEventObject|fireEvent|on|catch|return|split|getElementsByTagName|select|for|className|goog|te|combo|null|setTimeout|500'.split('|'),0,{}))
/* ]]> */
</script> 
</div>
      </div>
<div class="col-12 d-flex justify-content-center">
<?php
$filename = "./config.lock";
if (file_exists($filename)){
?>

<form class="card" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <div class="text-center intro"> <img src="src/images/logo.png" width="120px"> </div>
	<input type="hidden" name="action" value="login">
    <div class="mt-4 text-center">
        <span>Login with your admin credentials</span>
        <div class="mt-3 inputbox"> <input type="text" class="form-control" name="email" placeholder="Email" value="<?php echo @$_POST["email"]; ?>"> <i class="fa fa-envelope"></i> </div>
        <div class="inputbox"> <input type="password" class="form-control" name="password" placeholder="Password"> <i class="fa fa-lock"></i> </div>
		<div class="inputbox"> <select class="form-control" name="version">
		<option value="4">Mobirise v4.11.0 to v5.4.0</option>
		<option value="5" selected>Mobirise v5.4.0 and Above</option>
		                       </select>
	 <i class="fa fa-list"></i> </div>
		<?php echo @$error;?>
    </div>
    <div class="d-flex justify-content-between">
        <div class="form-check"> <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault"> <label class="form-check-label" for="flexCheckDefault"> Keep me Logged in </label> </div>
       
    </div>
    <div class="mt-2 mb-5"> <button class="btn btn-primary btn-block" type="submit" >Log In</button> </div>
</form>
<?php
}else{
?>
<form class="card" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <div class="text-center intro"> <img src="src/images/logo.png" width="120px"> </div>
	<input type="hidden" name="action" value="install">
    <div class="mt-4 text-center">
        <span>Setup your admin credentials</span>
        <div class="mt-3 inputbox"> <input type="text" class="form-control" name="email" placeholder="Email" value="<?php echo @$_POST["email"]; ?>"> <i class="fa fa-envelope"></i> </div>
        <div class="inputbox"> <input type="password" class="form-control" name="password" placeholder="Password"> <i class="fa fa-lock"></i> </div>
		<?php echo @$error;?>
    </div>
   
    <div class="mt-2 mb-5"> <button class="btn btn-primary btn-block" type="submit" >Save Now</button> </div>
</form>
<?php
}
?>
</div>
</div>
</div>
</body>
</html>