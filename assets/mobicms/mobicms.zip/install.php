<?php
if (session_status() === PHP_SESSION_NONE){session_start();} 
if(!isset($_SESSION["mobipager"])){
echo "Access Denied";
exit;    
}
$message = ""; // initial message 
if(isset($_POST["add"]) && $_POST["add"] == "yes" ){
// Includs database connection
	include "db_connect.php";

	// Gets the data from post
	$pname = "ghfd";
function rrmdir($dir) {
  if (is_dir($dir)) {
    $files = scandir($dir);
    foreach ($files as $file)
    if ($file != "." && $file != "..") rrmdir("$dir/$file");
    rmdir($dir);
  }
  else if (file_exists($dir)) unlink($dir);
} 
function rcopy($src, $dst) {
  if (file_exists($dst)) rrmdir($dst);
  if (is_dir($src)) {
    mkdir($dst);
    $files = scandir($src);
    foreach ($files as $file)
    if ($file != "." && $file != "..") rcopy("$src/$file", "$dst/$file");
  }
  else if (file_exists($src)) copy($src, $dst);
}
function delTree($dir)
    { 
        $files = array_diff(scandir($dir), array('.', '..')); 

        foreach ($files as $file) { 
            (is_dir("$dir/$file")) ? delTree("$dir/$file") : unlink("$dir/$file"); 
        }
        return rmdir($dir); 
    }	
function rmdir_recursive($dir) {
    foreach(scandir($dir) as $file) {
       if ('.' === $file || '..' === $file) continue;
       if (is_dir("$dir/$file")) rmdir_recursive("$dir/$file");
       else unlink("$dir/$file");
   }

   rmdir($dir);
}
if($_FILES["zip_file"]["name"]) {
    $filename = $_FILES["zip_file"]["name"];
    $source = $_FILES["zip_file"]["tmp_name"];
    $type = $_FILES["zip_file"]["type"];

    $name = explode(".", $filename);
    $accepted_types = array('application/zip', 'application/x-zip-compressed', 'multipart/x-zip', 'application/x-compressed');
    foreach($accepted_types as $mime_type) {
        if($mime_type == $type) {
            $okay = true;
            break;
        } 
    }

    $continue = strtolower($name[1]) == 'mcmsext' ? true : false;
    if(!$continue) {
        $message = "<div class='bg-danger text-white'>The file you are trying to upload is not a valid .mcmsext file. Please try again.</div>";
        $cc = json_encode(array("status" => "Fail","code" => "500","message" => $message,"rtype" => "images/placeholder.png","rtype2" => "images/placeholder.png"));
        echo $cc;
        exit;
    }

  /* PHP current path */
  $path = dirname(__FILE__).'/plugins/';  // absolute path to the directory where zipper.php is in
  $filenoext = basename ($filename, '.zip');  // absolute path to the directory where zipper.php is in (lowercase)
  $filenoext = basename ($filenoext, '.ZIP');  // absolute path to the directory where zipper.php is in (when uppercase)

  $targetdir = $path . $pname; // target directory
  $targetzip = $path . $filename; // target zip file

  /* create directory if not exists', otherwise overwrite */
  /* target directory is same as filename without extension */

  if (is_dir($targetdir))  rmdir_recursive ( $targetdir);


  mkdir($targetdir, 0777);


  /* here it is really happening */

    if(move_uploaded_file($source, $targetzip)) {
        $zip = new ZipArchive();
        $x = $zip->open($targetzip);  // open the extension file to extract
        if ($x === true) {
            $zip->extractTo($targetdir); // place in the directory with same name  
            $zip->close();
            unlink($targetzip);
        }
		$setupfile =  "./plugins/".$pname.'/params.json';
		$setup = @file_get_contents($setupfile);
		if(!empty($setup)){
		$setup = json_decode($setup, true);
		$plugin_name = $setup["name"];
		$plugin_title = $setup["title"];
		$plugin_description = $setup["description"];
		$plugin_type = $setup["plugin-type"];
		$plugin_code = $setup["version"];
		$checkplugin = $db->query("SELECT id FROM page WHERE pagetype = 'plugin' AND name = '".SQLite3::escapeString($plugin_name)."' LIMIT 1");
		$match_row = $checkplugin->fetchArray(); // set the row in $data
		if(empty($match_row["id"])){
		// Makes query with post data
		$query = "INSERT INTO page (status, name, title, pagetype, plugintype, plugincode, description, content) VALUES ('Active', '".SQLite3::escapeString($plugin_name)."', '".SQLite3::escapeString($plugin_title)."', 'plugin', '".SQLite3::escapeString($plugin_type)."', '".SQLite3::escapeString($plugin_code)."', '".SQLite3::escapeString($plugin_description)."', '')";
		}else{
		$query = "UPDATE page set title = '".SQLite3::escapeString($plugin_title)."', plugincode = '".SQLite3::escapeString($plugin_code)."', description = '".SQLite3::escapeString($plugin_description)."' WHERE id = '".$match_row["id"]."'";	
		}
			
	// Executes the query
	// If data inserted then set success message otherwise set error message
	// Here $db comes from "db_connection.php"
	if( $db->exec($query) or die($db->lastErrorMsg())){
		if(empty($match_row["id"])){
		rename("./plugins/".$pname, "./plugins/".$plugin_name);
		$message = "<div class='bg-success text-white'>Plugin have been installed successfully.</div>";
		}else{
		rcopy("./plugins/".$pname,  "./plugins/".$plugin_name);
		delTree($targetdir);	
		$message = "<div class='bg-success text-white'>Plugin have been updated successfully.</div>";
		}
        $cc = json_encode(array("status" => "Success","code" => "200","message" => $message,"rtype" => "images/placeholder.png","rtype2" => "images/placeholder.png"));
        echo $cc;
        exit;
	}else{
		$message = "<div class='bg-danger text-white'>Sorry, Plugin was not installed.</div>";
		$cc = json_encode(array("status" => "Fail","code" => "500","message" => $message,"rtype" => "images/placeholder.png","rtype2" => "images/placeholder.png"));
        echo $cc;
        exit;
	}
		}else{
			delTree($targetdir);
			$message = "<div class='bg-danger text-white'>Invalid or corrupt Plugin File.</div>";
			$cc = json_encode(array("status" => "Fail","code" => "500","message" => $message,"rtype" => "images/placeholder.png","rtype2" => "images/placeholder.png"));
        echo $cc;
        exit;
		}
        
    } else {    
        $message = "<div class='bg-danger text-white'>There was a problem with the upload. Please try again.</div>";
		$cc = json_encode(array("status" => "Fail","code" => "500","message" => $message,"rtype" => "images/placeholder.png","rtype2" => "images/placeholder.png"));
        echo $cc;
        exit;
    }
}else{
$message = "<div class='bg-danger text-white'>Sorry, Plugin file is needed.</div>";	
$cc = json_encode(array("status" => "Fail","code" => "500","message" => $message,"rtype" => "images/placeholder.png","rtype2" => "images/placeholder.png"));
        echo $cc;
        exit;
}	
	
		
}
?>

	<div class='main-container  bg-dark'>
<div class="container-fluid pb-2 pt-2">
<div class="modal-content p-4 pb-4 pt-4">


<div class="border-bottom mb-0 row">
<div class="col text-center"><h4><b>Install New Plugin</b></h4></div>
</div>
<div class="formspec">
<form class="pluginform" enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING']) ?>" method="post">
<input type="hidden" name="add" value="yes">
<div class="form-group mt-5">
<div class="text-center">
<label>Click on image to choose plugin file</label><br>
<label for="FileInput">
    <img src="./src/images/placeholder.png" width="300px" height="200px" id="plaaceimg" style="cursor:pointer" />
</label>
    <input type="file" name="zip_file" id="FileInput"  accept=".mcmsext" required style="cursor: pointer;  display: none"/>

</div>
<div class="col-md-12 p-3 text-center loader" style="display: none"><img src="./src/images/loading.gif"/></div>
<div class="col-md-12 p-3 text-center response"></div>
					</div>
					
					

</form>



   
  </div>
  
  </div>	
</div>	
</div>
   <script>
$(document).ready(function(){
function installplugin()
   {
$(".response").hide();	   
$(".loader").show();	      
var formData = new FormData($(".pluginform")[0]);
   $.ajax({
       url: './install.php',
       type: 'POST',
       data: formData,
       cache: false,
       contentType: false,
       enctype: 'multipart/form-data',
       processData: false
   }).done(function (data2) {
data = JSON.parse(data2);
console.log(data);
$(".loader").hide();
$(".response").show();	   
$(".response").html(data.message);
}).fail(function (error) {
$(".ajaxloading").hide();
$(".response").html("Error : Was not able to proccess your request at the moment");	
}).always(function (cdata) {
});	   
	     
} 

$( "#FileInput" ).change(function() {
      installplugin();
    });
	
});		    
</script>