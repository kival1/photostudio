<?php
session_start();
error_reporting(0);
if(!isset($_SESSION["mobipager"])){	
include "../../404.php";
exit;	
}else{
if (!is_dir("../../storage/usermanager/")) {
    mkdir("../../storage/usermanager/", 0777, true);
}	
header("location: ./dashboard/");
exit;	
}
?>