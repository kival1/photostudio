<?php
session_start();
$settings = json_decode(file_get_contents("./mobicms/storage/usermanager_advance/settings.json"), true);
if(!isset($_SESSION[$settings["lsn"]])){	
header("location: ". $settings["sprpout"]);
exit;	
}
?>