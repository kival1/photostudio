<?php
session_start();
include "check.php";
// Turn off error reporting
error_reporting(0);
$settings = json_decode(file_get_contents("../../storage/usermanager/settings.json"), true);
$domain_name = @$_SERVER['SERVER_NAME'];
$signup_success_page = $settings["sprpin"];
$signup_error_page = "";
$login_success_page = $settings["sprpin"];
$login_error_page = "";
$reset_success_page = "";
$reset_error_page = "";
$error_message = "";
// Includs database connection
require "./db_connect.php";
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['form_name']) && $_POST['form_name'] == 'signupform')
{	
if($settings["ens"] == "Disable"){
$arr = array("stat" => "fail", "returned" => "Sorry your new accounts is not accepted now, please try again later.");
$db->close();
echo json_encode($arr);
exit;	
}  
   $newusername = @$_POST['username'];
   $newemail = @$_POST['email'];
   $newpassword = @$_POST['password'];
   $confirmpassword = @$_POST['confirmpassword'];
   $newfullname = @$_POST['fullname'];
   $newgender = @$_POST['gender'];
   $newphone = @$_POST['phone'];
   $newstatus = "Active";
   $newtype = "User";
   $newexpire = "";
   if (isset($_POST['username']) && !preg_match("/^[A-Za-z0-9-_!@$]{1,50}$/", $newusername))
   {
	  $error_message .= 'Username is not valid, please check and try again!<br>';
   }
   else
   if (empty($_POST['password']) || !preg_match("/^[A-Za-z0-9-_!@$]{1,50}$/", $newpassword))
   {
      $error_message .= 'Password is not valid, please check and try again!<br>';
   }
   else
   if(isset($_POST['fullname']) && empty($_POST['fullname']) && !preg_match("/^[A-Za-z0-9-_!@$.' &]{1,50}$/", $newfullname))
   {
      $error_message .= 'Fullname is not valid, please check and try again!<br>';
   }
   else
   if (isset($_POST['email']) && empty($_POST['email']) && !preg_match("/^.+@.+\..+$/", $newemail))
   {
      $error_message .= 'Email is not a valid email address. Please check and try again!<br>';
   }
   else
   if (isset($_POST['phone']) && !preg_match("/^[0-9-_!@$]{1,50}$/", $_POST['phone']))
   {
      $error_message .= 'Invalid Phone number!<br>';
   }
   else
   if (isset($_POST['gender']) &&  empty($_POST['gender']))
   {
      $error_message .= 'Gender Is Needed!<br>';
   }
   if(isset($_POST['username']) && isset($_POST['email'])){
   $checkuser = SQLite3::escapeString ($newusername); // Escape value to protect against sql injection attack 
   $checkemail2 = SQLite3::escapeString ($newemail); // Escape value to protect against sql injection attack 
// Prepar the query to check the row data with this username
$query = "SELECT * FROM users WHERE username='".$checkuser."' OR  email='".$checkemail2."' LIMIT 1";
   }else
   if(isset($_POST['username']) && !isset($_POST['email'])){
	   $checkuser = SQLite3::escapeString ($newusername); // Escape value to protect against sql injection attack 
// Prepar the query to check the row data with this username
$query = "SELECT * FROM users WHERE username='".$checkuser."' LIMIT 1";   
   }elseif(isset($_POST['email']) && !isset($_POST['username'])){
   $checkemail2 = SQLite3::escapeString ($newemail); // Escape value to protect against sql injection attack 
// Prepar the query to check the row data with this username
$query = "SELECT * FROM users WHERE email='".$checkemail2."' LIMIT 1";    
   }
   
$result = $db->query($query) or die($db->lastErrorMsg());
$match_row = $result->fetchArray(); // set the row in $data
   if (!empty($match_row["id"]))
     {
         $error_message .= 'Account already exist.<br>';
         
     }
	 
   if (empty($error_message))
   {
$npass = md5($newpassword);
	// Makes query with post data
	$query = "INSERT INTO users (username, password, email, fullname, phone, gender, status, type, expired) VALUES ('$newusername', '$npass', '$newemail', '$newfullname', '$newphone', '$newgender', '$newstatus', '$newtype', '$newexpire')";
	
	if( $db->exec($query) or die($db->lastErrorMsg()) ){
	  $_SESSION[$settings["lsn"]] = $newusername;
	  $_SESSION['username'] = $newusername;
      $_SESSION['fullname'] = $newfullname;
      $_SESSION['email'] = $newemail;
	  $_SESSION['type'] = "User";
	  $_SESSION['status'] = "Active";
	  $arr =  array("stat" =>"success", "returned" => $signup_success_page);
	  $db->close();
	  echo json_encode($arr);
      exit;
	}else{
		$arr = array("stat" => "fail", "returned" => "Sorry your account was not created, please try again later.");
		$db->close();
	   echo json_encode($arr);
	   exit;
	}
	  
      
   }else{
	   $arr = array("stat" => "fail", "returned" => $error_message);
	   $db->close();
	   echo json_encode($arr);
	   exit;
   }
}
elseif ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['form_name']) && $_POST['form_name'] == 'loginform')
{
   
   $success_page = $login_success_page;
   $error_page = $login_error_page;
   $crypt_pass = md5($_POST['password']);
   if(isset($_POST['username'])){
   $logintype = $_POST['username'];
    $loginuser = SQLite3::escapeString(@$logintype); // Escape value to protect against sql injection attack 
	$loginpassword = SQLite3::escapeString(@$crypt_pass); // Escape value to protect against sql injection attack 
   // Prepar the query to check the row data with this username
$query = "SELECT * FROM users WHERE username='".$loginuser."' AND password = '".$loginpassword."' LIMIT 1";
   }else{
	$logintype = $_POST['email']; 
	    $loginuser = SQLite3::escapeString(@$logintype); // Escape value to protect against sql injection attack 
	$loginpassword = SQLite3::escapeString(@$crypt_pass); // Escape value to protect against sql injection attack 
   // Prepar the query to check the row data with this username
$query = "SELECT * FROM users WHERE email='".$loginuser."' AND password = '".$loginpassword."' LIMIT 1";
   }
   $found = false;
   $fullname = '';
   $session_timeout = 600; 
$result = $db->query($query) or die($db->lastErrorMsg());
$match_row = $result->fetchArray(); // set the row in $data
if(empty($match_row["id"]))
   {
      $arr = array("stat" => "fail", "returned" => "Account Not Found");
	  $db->close();
	   echo json_encode($arr);
	   exit;
   }
   if($match_row["status"] == "Suspended")
   {
      $arr = array("stat" => "fail", "returned" => "Your account is Suspended");
	  $db->close();
	   echo json_encode($arr);
	   exit;
   }
if($match_row["status"] != "Active"){
	$arr = array("stat" => "fail", "returned" => "Account Not Yet Activated by Admin");
	  $db->close();
	   echo json_encode($arr);
	   exit;   
   }
   else
   {
      if (session_id() == "")
      {
         session_start();
      }
      $_SESSION[$settings["lsn"]] = $match_row["id"];
	  $_SESSION['username'] = $match_row["username"];
      $_SESSION['fullname'] = $match_row["fullname"];
      $_SESSION['email'] = $match_row["email"];
	  $_SESSION['type'] = $match_row["type"];
	  $_SESSION['status'] = $match_row["status"];
      $rememberme = isset($_POST['rememberme']) ? true : false;
      if ($rememberme)
      {
         setcookie('username', $loginuser, time() + 3600*24*30);
         setcookie('password', $loginpassword, time() + 3600*24*30);
      }
	  $arr =  array("stat" =>"success", "returned" => $login_success_page);
	  $db->close();
	  echo json_encode($arr);
      exit;
   }
$username = isset($_COOKIE['username']) ? $_COOKIE['username'] : '';
$password = isset($_COOKIE['password']) ? $_COOKIE['password'] : '';
}
elseif ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['form_name']) && $_POST['form_name'] == 'forgotpassword')
{
   $success_page = $reset_success_page;
   $error_page = $reset_error_page;
if(isset($_POST['username'])){
   $logintype = $_POST['username'];
    $loginuser = SQLite3::escapeString(@$logintype); // Escape value to protect against sql injection attack 
   // Prepar the query to check the row data with this username
$query = "SELECT * FROM users WHERE username='".$loginuser."'  LIMIT 1";
   }else{
	$logintype = $_POST['email']; 
	$loginuser = SQLite3::escapeString(@$logintype); // Escape value to protect against sql injection attack 
   // Prepar the query to check the row data with this username
$query = "SELECT * FROM users WHERE email='".$loginuser."' LIMIT 1";
   }
   
$result = $db->query($query);
$match_row = $result->fetchArray(); // set the row in $data
   if (!empty($match_row["id"]))
   {
include "setpath.php";
$siteurl = $url;
function generateRandomString($length = 15) {
    return substr(str_shuffle(str_repeat($x='abcdefghijkmnpqrstuvwxyz23456789', ceil($length/strlen($x)) )),1,$length);
}
$crypt_pass = generateRandomString();
	 	  if(isset($_POST['username'])){ 
	  $usern = $match_row["username"];
	  // Makes query with post data
	$query = "UPDATE users set expired='$crypt_pass' WHERE username='$usern'";
		  }else{
	  $usern = $match_row["email"];
	  // Makes query with post data
	$query = "UPDATE users set expired='$crypt_pass' WHERE email='$usern'";	  
		  }
     if( $db->exec($query) ){ 
	  $mailto = $match_row["email"];
      $subject = 'Password Reset';
      $message = 'Your new password for password reset from '.$domain_name.' if that is true, then click on this link to reset your password:  <a target="_blank" href="'.$siteurl.'change.html?resetcode='.$crypt_pass.'&uid='.$match_row["id"].'">'.$siteurl.'change.html?resetcode='.$crypt_pass.'&uid='.$match_row["id"].'</a> \r\n . But you did not request for password reset, please ignore this message';
      $header  = "From: account@".$domain_name.""."\r\n";
      $header .= "Reply-To: .account@".$domain_name.""."\r\n";
      $header .= "MIME-Version: 1.0"."\r\n";
      $header .= "Content-Type: text/plain; charset=utf-8"."\r\n";
      $header .= "Content-Transfer-Encoding: 8bit"."\r\n";
      $header .= "X-Mailer: PHP v".phpversion();
      mail($mailto, $subject, $message, $header);
	  $arr = array("stat" => "Ok", "returned" => "An Instruction on how to reset your password have been sent to your Mail.");
	  $db->close();
	   echo json_encode($arr);
	   exit;
	}else{
		$arr = array("stat" => "fail", "returned" => "Was Not able to process your request.");
		$db->close();
	   echo json_encode($arr);
	   exit;
	} 
      
   }
   else
   {
      $arr = array("stat" => "fail", "returned" => "Account Not Found");
	  $db->close();
	   echo json_encode($arr);
	   exit;
   }
   exit;
}elseif ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['form_name']) && $_POST['form_name'] == 'changepassform')
{
   $success_page = $reset_success_page;
   $error_page = $reset_error_page;
   if(empty($_POST['password']) || $_POST['password'] != $_POST['rpassword']){
	$arr = array("stat" => "fail", "returned" => "Mis-matched password submited");
	  $db->close();
	   echo json_encode($arr);
	   exit;
   }
   if(empty($_POST['uid']) || empty($_POST['acctcode'])){
      $arr = array("stat" => "fail", "returned" => "Invalid Request, please provide a valid credentials");
	  $db->close();
	   echo json_encode($arr);
	   exit;
   }
   $logintype = $_POST['uid'];
   $loginuser = SQLite3::escapeString(@$logintype); // Escape value to protect against sql injection attack 
   $query = "SELECT * FROM users WHERE id = '".$loginuser."'  LIMIT 1";  
   $result = $db->query($query);
   $match_row = $result->fetchArray(); // set the row in $data
   if (!empty($match_row["id"]) && $match_row["expired"] == $_POST['acctcode'])
   {
function generateRandomString($length = 15) {
    return substr(str_shuffle(str_repeat($x='abcdefghijkmnpqrstuvwxyz23456789', ceil($length/strlen($x)) )),1,$length);
}
   $crypt_pass = generateRandomString();
   $newpassword = SQLite3::escapeString($_POST['password']);
	$newpassword = md5($newpassword);
	$usern = $match_row["id"];
	$query = "UPDATE users set password = '$newpassword', expired = '$crypt_pass' WHERE id = '$usern'";
     if( $db->exec($query) ){ 
	  $arr = array("stat" => "fail", "returned" => "Your password has been changed");
	  $db->close();
	   echo json_encode($arr);
	   exit;
	}else{
		$arr = array("stat" => "fail", "returned" => "Unable to process your request.");
		$db->close();
	   echo json_encode($arr);
	   exit;
	} 
      
   }
   else
   {
      $arr = array("stat" => "fail", "returned" => "Invalid Request, please provide a valid credentials");
	  $db->close();
	   echo json_encode($arr);
	   exit;
   }
   exit;
}else{
$arr = array("stat" => "fail", "returned" => "Unable to process your request.");
		$db->close();
	   echo json_encode($arr);
	   exit;	
}
?>