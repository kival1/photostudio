<?php
session_start();
$settings = json_decode(file_get_contents("../../storage/usermanager_advance/settings.json"), true);
$locate = "../../../".$settings["sprpout"];
unset($_SESSION[$settings["lsn"]]);
header("location: ". $locate);
exit;

?>