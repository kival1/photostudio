<?php
if ((isset($_SERVER['HTTP_REFERER']) && !empty($_SERVER['HTTP_REFERER']))) {
if (strtolower(parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST)) != strtolower($_SERVER['HTTP_HOST'])) {
	$arr = array("stat" => "fail", "returned" => "Not allowded - Unknown host request!");
$db->close();
echo json_encode($arr);
exit;
}
}
?>