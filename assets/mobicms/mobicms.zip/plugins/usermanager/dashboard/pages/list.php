<?php
session_start();
if(!isset($_SESSION["mobipager"])){	
echo "Access Denied, please login with your admin crededentials";
exit;	
}


// Makes query with rowid
$query = "SELECT * FROM users";

// Run the query and set query result in $users database
// Here $db comes from "db_connection.php"
$result = $db->query($query) or die($db->lastErrorMsg());

?>
<div class='main-container bg-dark'>
<div class="container-fluid pb-3 pt-3">
<div class="modal-content p-4 pb-4 pt-4">


<div class="border-bottom mb-3 row">
<div class="col text-center"><h4><b>Users listing</b></h4></div>
</div>
<div class="formspec">		
		
		<table  class="table table-bordered table-striped" id="users">
			<thead>
				<th>ID</th>
				<th width="20%"  scope="col">Name</th>
				<th width="20%" scope="col">Email</th>
				<th width="15%" scope="col">Username</th>
				<th width="5%" scope="col">Type</th>
				<th width="5%" scope="col">Status</th>
				<th>Action</th>
			</thead>
			<?php 
			while($row = $result->fetchArray()) {
				?>
			<tr class="userslist">
				<td data-label="ID"><?php echo $row['id'];?></td>
				<td data-label="Name"><?php echo $row['fullname'];?></td>
				<td data-label="Email"><?php echo @$row['email'];?></td>
				<td data-label="Username"><?php echo @$row['username'];?></td>
				<td data-label="Type"><?php echo @$row['type'];?></td>
				<td data-label="Status"><?php echo $row['status'];?></td>
				<td data-label="Action">
					<a href="?page_action=profile&uid=<?php echo $row['id'];?>" class="btn btn-sm btn-primary"><i class="fa fa-search"></i></a> |
					<a href="?page_action=update&uid=<?php echo $row['id'];?>" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a></a> | 
					<a href="?page_action=delete&uid=<?php echo $row['id'];?>"  class="btn btn-sm btn-danger confirmation"><i class="fa fa-trash"></i></a></a>
				</td>
			</tr>
			<?php } 
			?>
		</table>

  </div>
  </div>	
</div>	
</div>
<script>
$(document).ready(function(){
	var table = $('#users').DataTable();

})
</script>