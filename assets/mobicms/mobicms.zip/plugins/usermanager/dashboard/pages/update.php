<?php
session_start();
error_reporting(0);
if(!isset($_SESSION["mobipager"])){	
echo "Access Denied, please login with your admin crededentials";
exit;	
}
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{	
   
   $newusername = SQLite3::escapeString (@$_POST['username']);
   $newemail = SQLite3::escapeString(@$_POST['email']);
   $newpassword = SQLite3::escapeString(@$_POST['password']);
   $newfullname = SQLite3::escapeString(@$_POST['fullname']);
   $newgender = SQLite3::escapeString(@$_POST['gender']);
   $newphone = SQLite3::escapeString(@$_POST['phone']);
   $newstatus = SQLite3::escapeString(@$_POST['status']);

   if (empty($_POST['username']) && empty($_POST['email']))
   {
      $error_message = 'Atleast Email Or Username Field is needed for login!<br>';
   }
   else
   if (!empty($_POST['username']) && !preg_match("/^[A-Za-z0-9-_!@$]{1,50}$/", $newusername))
   {
	  $error_message .= 'Username is not valid!<br>';
   }
   else
   if (!empty($_POST['password']) && !preg_match("/^[A-Za-z0-9-_!@$]{1,50}$/", $newpassword))
   {
      $error_message .= 'Password is not valid!<br>';
   }
   else
   if(empty($_POST['fullname']) || !preg_match("/^[A-Za-z0-9 -_!@$]{1,50}$/", $newfullname))
   {
      $error_message .= 'Fullname is not valid!<br>';
   }
   else
   if (!empty($_POST['email']) && !preg_match("/^.+@.+\..+$/", $newemail))
   {
      $error_message .= 'Email is not a valid email!<br>';
   }
   else
   if (!empty($_POST['phone']) && !preg_match("/^[0-9-_!@$]{1,50}$/", $_POST['phone']))
   {
      $error_message .= 'Invalid Phone number!<br>';
   }
   else
   if (!empty($_POST['gender']) &&  !preg_match("/^[A-Za-z0-9-_!@$]{1,50}$/", $_POST['gender']))
   {
      $error_message .= 'Invalid Gender!<br>';
   } 

	 
   if (empty($error_message))
   {
$uid =  $_POST["uid"];    
   if(!empty($_POST['password'])){
   $npass = md5($newpassword); 
// Prepar the query to update the row data
	$query = "UPDATE users set username='$newusername', email='$newemail', fullname='$newfullname', gender='$newgender', status='$newstatus', phone='$newphone', password='$npass' WHERE id='$uid'";	
   }else{
// Prepar the query to update the row data
	$query = "UPDATE users set username='$newusername', email='$newemail', fullname='$newfullname', gender='$newgender', status='$newstatus', phone='$newphone' WHERE ID='$uid'";	
   }	   

	
	if( $db->exec($query) or die($db->lastErrorMsg()) ){
	  $arr =  "<div class='bg-dark text-white text-center p-1 mb-1'>Account has been updated Successfully.</div>";

	}else{
		$arr =  "<div class='bg-danger text-white text-center p-1 mb-1'>Sorry account was not updated, please try again later.</div>";

	}
	  
      
   }else{
	  $arr =  "<div class='bg-danger text-white text-center p-1 mb-1'>".$error_message."</div>"; 
   }
}
 if(!empty($_GET['uid'])){
	   $checkuser = SQLite3::escapeString ($_GET['uid']); 
	   // Escape value to protect against sql injection attack 
// Prepar the query to check the row data with this username
$query = "SELECT * FROM users WHERE id ='".$checkuser."' LIMIT 1";   
   } 
$result = $db->query($query) or die($db->lastErrorMsg());
$match_row = $result->fetchArray(); // set the row in $data
?>

<div class='main-container bg-dark'>
<div class="container-fluid pb-3 pt-3">
<div class="modal-content p-4 pb-4 pt-4">

<div class="border-bottom mb-3 row">
<div class="col text-center"><h4><b>Update User Info</b></h4></div>
</div>
<div class="container">
    <div class="row ">
        <div class="col-lg-12 mx-auto">
            <div class="card mt-4 mx-auto p-0">
                <div class="card-body">
                    <div class="container-fluid">
                        <form id="update-form" role="form" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING']) ?>">
                            <div class="controls">
                                <div class="row">
								<div class="col-md-12"><?php echo @$arr;?></div>
                                    <div class="col-md-12">
									<input type="hidden" value="<?php echo @$match_row["id"];?>" name="uid">
                                        <div class="form-group"> <label for="form_name">Fullname *</label> <input id="form_name" type="text" name="fullname" class="form-control" placeholder="Please enter your fullname *" required="required" data-error="Fullname is required."  value="<?php echo @$match_row["fullname"];?>"> </div>
                                    </div>
									<div class="col-md-6">
                                        <div class="form-group"> <label for="form_need">Account Status</label> <select id="form_need" name="status" class="form-control">
                                                <option value=""  disabled>--Select--</option>
                                                <option value="Active" <?php echo $match_row["status"] == "Active" ? "selected" : "";?>>Activate</option>
												<option value="Pending" <?php echo $match_row["status"] == "Pending" ? "selected" : "";?>>Pending</option>
												<option value="Suspended" <?php echo $match_row["status"] == "Suspended" ? "selected" : "";?>>Suspend</option>
                                            </select> </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group"> <label for="form_need">Gender</label> <select id="form_need" name="gender" class="form-control" data-error="Please specify your need.">
                                                <option value=""  disabled>--Select Your Gender--</option>
                                                <option value="Male" <?php echo $match_row["gender"] == "Male" ? "selected" : "";?>>Male</option>
												<option value="Female" <?php echo $match_row["gender"] == "Female" ? "selected" : "";?>>Female</option>
                                                <option value="Others" <?php echo $match_row["gender"] == "Others" ? "selected" : "";?>>Others</option>
                                            </select> </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group"> <label for="form_email">Email</label> <input id="form_email" type="email" name="email" class="form-control" placeholder="Please enter your email"  data-error="Valid email is required" value="<?php echo @$match_row["email"];?>"> </div>
                                    </div>
									<div class="col-md-6">
                                        <div class="form-group"> <label for="form_phone">Phone No</label> <input id="form_phone" type="text" name="phone" class="form-control" placeholder="Please enter your phone number" value="<?php echo @$match_row["phone"];?>"> </div>
                                    </div>
                                    
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group"> <label for="form_email">Username</label> <input id="form_username" type="text" name="username" class="form-control" placeholder="Please enter Username "  data-error="Valid email is required" value="<?php echo @$match_row["username"];?>"> </div>
                                    </div>
									<div class="col-md-6">
                                        <div class="form-group"> <label for="form_phone">New Password</label> <input id="form_password" type="password" name="password" class="form-control" placeholder="Leave blank if don't want to update password"> </div>
                                    </div>
                                    <div class="modal-footer col-md-12">
        <button type="submit" class="btn btn-dark ajaxbtns" ><span class="fa fa-save"></span>&nbsp;&nbsp;Save</button>
      </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div> <!-- /.8 -->
        </div> <!-- /.row-->
    </div>
</div>

  </div>	
</div>	
</div>
<?php
$db->close();
?>