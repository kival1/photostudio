<?php
session_start();
if(!isset($_SESSION["mobipager"])){	
echo "Access Denied, please login with your admin crededentials";
exit;	
}
if(!empty($_GET["uid"])){
$uid = SQLite3::escapeString($_GET['uid']);
// Makes query with uid
$query = "DELETE FROM users WHERE id = '$uid'";

// Run the query
if( $db->exec($query)or die($db->lastErrorMsg()) ){
	 echo "<div class='bg-success text-white text-center p-5'>Account has been deleted Successfully.</div>";
	}else{
		echo  "<div class='bg-danger text-white text-center p-5'>Sorry account was not deleted, please try again later.</div>";
	} 
}
?>

