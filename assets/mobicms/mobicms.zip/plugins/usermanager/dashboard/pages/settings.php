<?php
session_start();
error_reporting(0);
if(!isset($_SESSION["mobipager"])){	
echo "Access Denied, please login with your admin crededentials";
exit;	
}
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
if (!is_dir("../../../storage/usermanager/")) {
    mkdir("../../../storage/usermanager/", 0777, true);
}	
$encode_data = json_encode($_POST);
file_put_contents("../../../storage/usermanager/settings.json", $encode_data);
$arr = "<div class='bg-success text-white text-center p-1 mb-1'><h5>Settings have been updated</h5></div>";   

}

$match_row = json_decode(file_get_contents("../../../storage/usermanager/settings.json"), true);
?>

<div class='main-container bg-dark'>
<div class="container-fluid pb-3 pt-3">
<div class="modal-content p-4 pb-4 pt-4">

<div class="border-bottom mb-3 row">
<div class="col text-center"><h4><b>Settings</b></h4></div>
</div>
<div class="container">
    <div class="row ">
        <div class="col-lg-12 mx-auto">
            <div class="card mt-4 mx-auto p-0">
                <div class="card-body">
                    <div class="container-fluid">
                        <form id="update-form" role="form" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING']) ?>">
                            <div class="controls">
                                <div class="row">
								<div class="col-md-12"><?php echo @$arr;?></div>
                                    <div class="col-md-6">
                                        <div class="form-group"> <label for="form_name">Redirect Page After login *</label> <input id="form_name" type="text" name="sprpin" class="form-control" placeholder="Success login redirection" required="required" data-error="Success login redirection"  value="<?php echo @$match_row["sprpin"];?>"> </div>
                                    </div>
									<div class="col-md-6">
                                        <div class="form-group"> <label for="form_name">Redirect Page After Logout *</label> <input id="form_name" type="text" name="sprpout" class="form-control" placeholder="Success logout redirection" required="required" data-error="Success login redirection"  value="<?php echo @$match_row["sprpout"];?>"> </div>
                                    </div>
									<div class="col-md-6">
                                        <div class="form-group"> <label for="form_name">Login Session Name *</label> <input id="form_name" type="text" name="lsn" class="form-control" placeholder="Name of PHP session name" required="required"  value="<?php echo @$match_row["lsn"];?>"> </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group"> <label for="form_need">Access account with<span class="small"> (Email or Username)</span></label> <select id="form_need" name="aac" class="form-control">
                                                <option value=""  disabled>--Select--</option>
                                                <option value="Email" <?php echo $match_row["aaw"] == "Email" ? "selected" : "";?>>Email</option>
												<option value="Username" <?php echo $match_row["aac"] == "Username" ? "selected" : "";?>>Username</option>
                                            </select> </div>
                                    </div>
									<div class="col-md-6">
                                        <div class="form-group"> <label for="form_need">Enable/Disable New Signup<span class="small"></span></label> <select id="form_need" name="ens" class="form-control">
                                                <option value=""  disabled>--Select--</option>
                                                <option value="Enable" <?php echo $match_row["ens"] == "Enable" ? "selected" : "";?>>Enable</option>
												<option value="Disable" <?php echo $match_row["ens"] == "Disable" ? "selected" : "";?>>Disable</option>
                                            </select> </div>
                                    </div>
									<div class="col-md-6">
                                        <div class="form-group"> <label for="form_need">Default Account Status<span class="small"> (On Signup)</span><span class="small"></span></label> <select id="form_need" name="das" class="form-control">
                                                <option value=""  disabled>--Select--</option>
                                                <option value="Active" <?php echo $match_row["das"] == "Active" ? "selected" : "";?>>Active</option>
												<option value="Pending" <?php echo $match_row["das"] == "Pending" ? "selected" : "";?>>Pending</option>
                                            </select> </div>
                                    </div>
									
                                    
                                </div>
                                <div class="row">
                                    <div class="modal-footer col-md-12">
        <button type="submit" class="btn btn-dark ajaxbtns" ><span class="fa fa-save"></span>&nbsp;&nbsp;Save</button>
      </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div> <!-- /.8 -->
        </div> <!-- /.row-->
    </div>
</div>

</div>	
</div>	
</div>
<?php
$db->close();
?>