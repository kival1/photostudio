<?php
session_start();
error_reporting(0);
if(!isset($_SESSION["mobipager"])){	
header("location: ../../../login.php");
exit;	
}
if ($_GET["action"] == 'logout')
      {
         unset($_SESSION["mobipager"]);
         header("location: ../../../login.php");
         exit;
      }	  
// Includs database connection
require "db_connect.php";
$match_row = json_decode(@file_get_contents("../../../storage/usermanager/settings.json"), true);
if(!$match_row){
$match_row = file_get_contents("./settings.json");
file_put_contents("../../../storage/usermanager/settings.json", $match_row);	
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>User Manager dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="../css/style.css" rel="stylesheet">
	<?php if(!isset($_GET["page_action"])){?>
	     <link href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css" rel="stylesheet">
	<?php } ?>
	    <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<?php if(!isset($_GET["page_action"])){?>
			   <script src="https://cdn.datatables.net/v/bs4/dt-1.10.24/b-1.5.6/sc-2.0.0/sl-1.3.0/datatables.min.js"></script>
		       <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
			   <?php } ?>

</head>
<body>
<div id="wrapper">
    <nav class="navbar header-top fixed-top navbar-expand-lg  navbar-dark bg-dark">
      <a class="navbar-brand" href="#">Dashboard</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText"
        aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarText">
	  
        <ul class="navbar-nav side-nav pr-2 pl-2">
           <div class="mt-5"></div>
		   <li class="nav-item">
              <a href="./" class="nav-link text-light p-3 mb-2 <?php echo empty($_GET["page_action"]) || $_GET["page_action"] == "" ? "current" : "nin";?>"> <i class="fa fa-list text-light fa-lg mr-3" aria-hidden="true"></i> User List</a>
         </li>
		   <li class="nav-item">
              <a href="./?page_action=add" class="nav-link text-light p-3 mb-2 <?php echo $_GET["page_action"] == "add" ? "current" : "nin";?>"> <i class="fa fa-edit text-light fa-lg mr-3" aria-hidden="true"></i> Add New User</a>
         </li>
		  <li class="nav-item">
              <a href="./?page_action=settings" class="nav-link text-light p-3 mb-2 <?php echo $_GET["page_action"] == "settings" ? "current" : "nin";?>"> <i class="fa fa-gears text-light fa-lg mr-3" aria-hidden="true"></i>Settings</a>
         </li>
			<li class="nav-item">
              <a  href="./?action=logout" class="nav-link text-light p-3 mb-2 nin"> <i class="fa fa-power-off text-light fa-lg mr-3" aria-hidden="true"></i> Logout</a>
            </li>
			<li class="nav-item text-center pt-3 text-white">
	  Change language
	  <div class="container">
       <!-- GTranslate: https://gtranslate.io/ -->
<a href="#" onclick="doGTranslate('en|nl');return false;" title="Dutch" class="gflag nturl" style="background-position:-0px -100px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="Dutch" /></a><a href="#" onclick="doGTranslate('en|en');return false;" title="English" class="gflag nturl" style="background-position:-0px -0px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="English" /></a><a href="#" onclick="doGTranslate('en|fr');return false;" title="French" class="gflag nturl" style="background-position:-200px -100px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="French" /></a><a href="#" onclick="doGTranslate('en|de');return false;" title="German" class="gflag nturl" style="background-position:-300px -100px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="German" /></a><a href="#" onclick="doGTranslate('en|it');return false;" title="Italian" class="gflag nturl" style="background-position:-600px -100px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="Italian" /></a><a href="#" onclick="doGTranslate('en|pt');return false;" title="Portuguese" class="gflag nturl" style="background-position:-300px -200px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="Portuguese" /></a><a href="#" onclick="doGTranslate('en|ru');return false;" title="Russian" class="gflag nturl" style="background-position:-500px -200px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="Russian" /></a><a href="#" onclick="doGTranslate('en|es');return false;" title="Spanish" class="gflag nturl" style="background-position:-600px -200px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="Spanish" /></a>
</div>

<style type="text/css">
<!--
a.gflag {vertical-align:middle;font-size:16px;padding:1px 0;background-repeat:no-repeat;background-image:url(//gtranslate.net/flags/16.png);}
a.gflag img {border:0;}
a.gflag:hover {background-image:url(//gtranslate.net/flags/16a.png);}
#goog-gt-tt {display:none !important;}
.goog-te-banner-frame {display:none !important;}
.goog-te-menu-value:hover {text-decoration:none !important;}
body {top:0 !important;}
#google_translate_element2 {display:none!important;}
-->
</style>

<select class="form-control" onchange="doGTranslate(this);"><option value="">Select Language</option><option value="en|af">Afrikaans</option><option value="en|sq">Albanian</option><option value="en|ar">Arabic</option><option value="en|hy">Armenian</option><option value="en|az">Azerbaijani</option><option value="en|eu">Basque</option><option value="en|be">Belarusian</option><option value="en|bg">Bulgarian</option><option value="en|ca">Catalan</option><option value="en|zh-CN">Chinese (Simplified)</option><option value="en|zh-TW">Chinese (Traditional)</option><option value="en|hr">Croatian</option><option value="en|cs">Czech</option><option value="en|da">Danish</option><option value="en|nl">Dutch</option><option value="en|en">English</option><option value="en|et">Estonian</option><option value="en|tl">Filipino</option><option value="en|fi">Finnish</option><option value="en|fr">French</option><option value="en|de">German</option><option value="en|el">Greek</option><option value="en|ht">Haitian Creole</option><option value="en|iw">Hebrew</option><option value="en|hi">Hindi</option><option value="en|hu">Hungarian</option><option value="en|is">Icelandic</option><option value="en|id">Indonesian</option><option value="en|ga">Irish</option><option value="en|it">Italian</option><option value="en|ja">Japanese</option><option value="en|ko">Korean</option><option value="en|lv">Latvian</option><option value="en|lt">Lithuanian</option><option value="en|mk">Macedonian</option><option value="en|ms">Malay</option><option value="en|mt">Maltese</option><option value="en|no">Norwegian</option><option value="en|fa">Persian</option><option value="en|pl">Polish</option><option value="en|pt">Portuguese</option><option value="en|ro">Romanian</option><option value="en|ru">Russian</option><option value="en|sr">Serbian</option><option value="en|sk">Slovak</option><option value="en|sl">Slovenian</option><option value="en|es">Spanish</option><option value="en|sw">Swahili</option><option value="en|sv">Swedish</option><option value="en|th">Thai</option><option value="en|tr">Turkish</option><option value="en|uk">Ukrainian</option><option value="en|vi">Vietnamese</option></select><div id="google_translate_element2"></div>
<script type="text/javascript">
function googleTranslateElementInit2() {new google.translate.TranslateElement({pageLanguage: 'en',autoDisplay: false}, 'google_translate_element2');}
</script><script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2"></script>


<script type="text/javascript">
/* <![CDATA[ */
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('6 7(a,b){n{4(2.9){3 c=2.9("o");c.p(b,f,f);a.q(c)}g{3 c=2.r();a.s(\'t\'+b,c)}}u(e){}}6 h(a){4(a.8)a=a.8;4(a==\'\')v;3 b=a.w(\'|\')[1];3 c;3 d=2.x(\'y\');z(3 i=0;i<d.5;i++)4(d[i].A==\'B-C-D\')c=d[i];4(2.j(\'k\')==E||2.j(\'k\').l.5==0||c.5==0||c.l.5==0){F(6(){h(a)},G)}g{c.8=b;7(c,\'m\');7(c,\'m\')}}',43,43,'||document|var|if|length|function|GTranslateFireEvent|value|createEvent||||||true|else|doGTranslate||getElementById|google_translate_element2|innerHTML|change|try|HTMLEvents|initEvent|dispatchEvent|createEventObject|fireEvent|on|catch|return|split|getElementsByTagName|select|for|className|goog|te|combo|null|setTimeout|500'.split('|'),0,{}))
/* ]]> */
</script> 
      </li>
        </ul>
        
      </div>
    </nav>
    <div class="container-fluid">
      <div class="row">
        <div class="col-12 pages">
<?php if(isset($_GET["page_action"])){
	require "./pages/".htmlspecialchars($_GET["page_action"]).".php";
	
}else{
	require "./pages/list.php";
}?>
        </div>
      </div>
      
    </div>
  </div>
<script>
    $(document).ready(function() {
		$(document).on("click",".confirmation", function() {
	return confirm("Are you sure you want to delete this account?");
})
    });
  </script>
</body>
</html>
