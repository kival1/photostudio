<?php
if (!is_dir("../../../storage/usermanager/")) {
    mkdir("../../../storage/usermanager/", 0777, true);
}
// Database name
$database_name = "../../../storage/usermanager/users.db3";
// Database Connection
$db = new SQLite3($database_name);
// Create Table "students" into Database if not exists 
$query = "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username STRING, email STRING, fullname STRING, phone STRING, gender STRING, password STRING, status STRING, expired STRING, type STRING)";
$db->exec($query);
?>