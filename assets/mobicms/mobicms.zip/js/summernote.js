function beautifycode(htmlstr){
    htmlstr = htmlstr.split(/\>[ ]?\</).join(">\n<");
    htmlstr = htmlstr.split(/([*]?\{|\}[*]?\{|\}[*]?)/).join("\n");
    htmlstr = htmlstr.split(/[*]?\;/).join("\;\n    ");
    return htmlstr;
}
 $(document).ready(function() {
	 $.upload = function (file) {
        let out = new FormData();
        out.append('file', file, file.name);
        $.ajax({
            method: 'POST',
            url: './upload.php',
            contentType: false,
            cache: false,
            processData: false,
            data: out,
            success: function (img) {
                $('.myGrid').summernote('insertImage', img);
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.error(textStatus + " " + errorThrown);
            }
        });
    };
            // Initialize grid editor
            $('#myGrid').gridEditor({
				source_textarea: '.myTextarea',
				row_classes: [{label: 'Bg-pri', cssClass: 'bg-primary'},{label: 'Bg-sec', cssClass: 'bg-secondary'},{label: 'Bg-suc', cssClass: 'bg-success'},{label: 'Bg-inf', cssClass: 'bg-info'},{label: 'Bg-lig', cssClass: 'bg-light'},{label: 'Bg-whi', cssClass: 'bg-white'},{label: 'p-u/d', cssClass: 'py-2'},{label: 'p-l/r', cssClass: 'px-2'}],
                col_classes: [{label: 'Bg-pri', cssClass: 'bg-primary'},{label: 'Bg-sec', cssClass: 'bg-secondary'},{label: 'Bg-suc', cssClass: 'bg-success'},{label: 'Bg-inf', cssClass: 'bg-info'},{label: 'Bg-lig', cssClass: 'bg-light'},{label: 'Bg-whi', cssClass: 'bg-white'},{label: 'p-u/d', cssClass: 'py-2'},{label: 'p-l/r', cssClass: 'px-2'}],
				new_row_layouts: [[12], [6, 6], [9, 3], [3, 9], [4, 4, 4]],
                content_types: ['summernote'],
                summernote: {
                    config: {
					blockquoteBreakingLevel: 0,
						popover: {
  image: [
    ['custom', ['imageAttributes']],
    ['image', ['resizeFull', 'resizeHalf', 'resizeQuarter', 'resizeNone']],
    ['float', ['floatLeft', 'floatRight', 'floatNone']],
    ['remove', ['removeMedia']]
  ],
  link: [
    ['link', ['linkDialogShow', 'unlink']]
  ],
  table: [
    ['add', ['addRowDown', 'addRowUp', 'addColLeft', 'addColRight']],
    ['delete', ['deleteRow', 'deleteCol', 'deleteTable']],
	['custom', ['tableStyles', 'tableHeaders']]
  ],
  air: [
    ['style', ['style', 'addclass', 'clear']],
    ['color', ['color']],
    ['font', ['underline','hr']],
    ['para', ['ul', 'ol', 'paragraph']],
	['height',['height']],
    ['table', ['table']],
    ['insert', ['link','videoAttributes','audio','media','picture', 'gallery']],
	['extensions', ['gallery']],
	['misc', ['undo', 'redo', 'help']],
  ]
},
        lang: 'en-US', // Change to your chosen language
        imageAttributes:{
            icon:'<i class="note-icon-pencil"/>',
            removeEmpty:false, // true = remove attributes | false = leave empty if present
            disableUpload: false // true = don't display Upload Options | Display Upload Options
        },
   gallery: {
                source: {
                    // data: data,
                    url: './gallery.php',
                    responseDataKey: 'data',
                    nextPageKey: 'links.next',
                },
                modal: {
                    loadOnScroll: true,
					maxHeight: 300,
                    title: "Image gallery",
                    noImageSelected_msg: 'No image was selected, please select one by clicking it!',
                }
            },
                  callbacks: {
			onImageUpload: function(files) {
                    $.upload(files[0]);
                
            }
                        }
				     }
				  }
            });
     $('form.pageform').on('submit', function() {
    var html = $('#myGrid').gridEditor('getHtml');
    $('.myTextarea').val(beautifycode(html));
});
        });
		