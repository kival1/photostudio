<?php
if (session_status() === PHP_SESSION_NONE){session_start();} 
if(!isset($_SESSION["mobipager"])){
echo "Access Denied";
exit;    
}
$message = ""; // initial message 
	// Includs database connection
	include "db_connect.php";
if(isset($_POST["postid"]) && !empty($_POST["postid"])){


	// Gets the data from post
	$id = SQLite3::escapeString($_POST['postid']);
	$status = SQLite3::escapeString(@$_POST['status']);
	$name = SQLite3::escapeString(@$_POST['name']);
	$title = SQLite3::escapeString(@$_POST['title']);
	$description = SQLite3::escapeString(@$_POST['description']);
	$content = SQLite3::escapeString (@$_POST['content']);

	// Makes query with post data
	$query = "UPDATE page set status='$status', name='$name', title='$title', description='$description', content='$content' WHERE id=$id";
	
	// Executes the query
	// If data inserted then set success message otherwise set error message
	// Here $db comes from "db_connection.php"
	if( $db->exec($query) or die($db->lastErrorMsg()) ){
		$message = "<div class='bg-success text-white'>Page have been updated successfully.</div>";
	}else{
		$message = "<div class='bg-danger text-white'>Sorry, Page was not updated.</div>";
	}
}
$id = SQLite3::escapeString ($_GET['id']); // rowid from url
// Prepar the query to get the row data with rowid
$query = "SELECT rowid, * FROM page WHERE id=$id LIMIT 1";
$result = $db->query($query);
$data = $result->fetchArray(); // set the row in $data
?>

 <!-- include summernote css/js -->
<link href="summernote/summernote-bs4.min.css?v=1" rel="stylesheet">
<script src="summernote/summernote-bs4.min.js"></script>
<link rel="stylesheet" type="text/css" href="../assets/mobirise/css/mbr-additional.css" />
<link rel="stylesheet" type="text/css" href="./dist/grideditor.css" />
<link rel="stylesheet" type="text/css" href="./css/editor.css" />
	<div class='main-container'>
<div class="container-fluid bg-dark pb-2 pt-2">
<div class="modal-content p-3">


<div class="border-bottom row">
<div class="col text-center"><h4><b>Update Page</b></h4></div>
</div>
<div class="formspec">



<form class="pageform" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING']) ?>" method="post">
<input type="hidden" name="postid" value="<?php echo empty($_POST["postid"]) ? $data["id"] : @$_POST["postid"];?>">
<!-- Tabs -->
<section id="tabs">
	<div class="container-fluid">
		<div class="row">
		<div class="col-md-12 p-0 text-center"><?php echo @$message; ?></div>
			<div class="col-md-12 ">
				<nav>
					<div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
						<a class="nav-item nav-link active" id="nav-title-settings-tab" data-toggle="tab" href="#nav-title-settings" role="tab" aria-controls="nav-home" aria-selected="true">Settings</a>
						<a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Meta Tags</a>
						<a class="nav-item nav-link" id="nav-about-tab" data-toggle="tab" href="#nav-about" role="tab" aria-controls="nav-about" aria-selected="false">Page Content</a>
					</div>
				</nav>
				<div class="tab-content py-1 px-1 px-sm-0 col-12 col-md-12 mt-3" id="nav-tabContent" style="width: 100%">
					<div class="tab-pane fade show active" id="nav-title-settings" role="tabpanel" aria-labelledby="nav-home-tab">
					<div class="col-12 col-md-12 col-lg-12">
						<div class="form-group">
						<label>Status</label>
		                 <select name="status" class="form-control custom-select  notranslate" required>
						 <option value="">Staus</option>
						 <option value="<?php echo empty($_POST["status"]) ? $data["status"] : @$_POST["status"];?>" <?php echo ($data["status"] == "active" ? "selected" : "")?>>active</option>
						 <option value="<?php echo empty($_POST["status"]) ? $data["status"] : @$_POST["status"];?>" <?php echo ($data["status"] == "disable" ? "selected" : "")?>>disable</option>
						 </select>
                         </div>
						 <div class="form-group">
                            <label>Page Name</label>
                            <input type="text" name="name" required class="form-control  notranslate" value="<?php echo empty($name) ? $data["name"] : @$name;?>" pattern="[a-zA-Z0-9-_]+">
                        </div>
						</div>
					</div>
					<div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
					    <div class="form-group">
                            <label>Title</label>
                            <input type="text" name="title" required class="form-control  notranslate" value="<?php echo empty($title) ? $data["title"] : @$title;?>">
                        </div>
						<div class="form-group">
                            <label>Description</label>
                            <textarea id="description" required name="description" class="form-control notranslate"><?php echo empty($description) ? htmlspecialchars($data["description"]) : @$description;?></textarea>
                        </div>
					</div>
					<div class="tab-pane fade" id="nav-about" role="tabpanel" aria-labelledby="nav-about-tab">
						
                            <div class="container-fluid  notranslate">
        <div id="myGrid"> </div> <!-- /#myGrid -->
    </div> <!-- /.container -->
	<div class="d-none">
                            <textarea id="bcontent"  name="content" class="form-control myTextarea  notranslate"><?php echo empty($content)  ? $data["content"] : @$content;?></textarea>
		</div>
                        
					</div>
					<div class="modal-footer ">
        <button type="submit" class="btn btn-dark ajaxbtns" ><span class="fa fa-save"></span>&nbsp;Save Page</button>
		 
      </div>
				</div>
			
			</div>
		</div>
	</div>
</section>
<!-- ./Tabs -->

</form>





   
  </div>
  
   
  </div>	
</div>	
</div>
    <script src="./dist/jquery.grideditor.min.js?v=2"></script>
	<script src="./summernote/plugin/upload/uploadapi.js?v=1"></script>
    <script src="./summernote/plugin/addclass<?php echo @$_SESSION["version"]; ?>.js?v=4"></script>
	<script src="./summernote/plugin/imageatt.js?v=1"></script>
	<script src="./summernote/plugin/custom.js?v=2"></script>
	<script src="./summernote/plugin/table.js?v=4"></script>
	<script src="./summernote/plugin/video.js?v=1"></script>
	<script src="./js/summernote.js?v=1"></script>
