<?php
if (session_status() === PHP_SESSION_NONE){session_start();} 
if(empty($_SESSION["mobipager"])){
header('Location: ./login.php');
exit;    
}
// Includs database connection
include "db_connect.php";

$id = SQLite3::escapeString ($_GET['id']); // rowid from url

// Prepar the deleting query according to rowid
$query = "DELETE FROM page WHERE rowid=$id";

// Run the query to delete record
if( $db->query($query) ){
	header('Location: ./index.php');
}else {
	$message = "Sorry, Record is not deleted.";
}

echo $message;
?>
<a href="index.php">Back to PageList</a>