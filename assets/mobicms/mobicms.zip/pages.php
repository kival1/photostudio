<?php
if (session_status() === PHP_SESSION_NONE){session_start();} 
if(!isset($_SESSION["mobipager"])){
echo "Access Denied";
exit;    
}
// Includs database connection
include "db_connect.php";

// Makes query with rowid
$query = "SELECT * FROM page WHERE pagetype = 'page' ";

// Run the query and set query result in $result
// Here $db comes from "db_connection.php"
$result = $db->query($query) or die($db->lastErrorMsg());

?>

	<div class='main-container  bg-dark'>
<div class="container-fluid pb-2 pt-2">
<div class="modal-content p-4 pb-4 pt-4">


<div class="border-bottom mb-3 row">
<div class="col text-center"><h4><b>Page listing</b></h4></div>
</div>
<div class="formspec">		
		
		<table id="pagelist" class="table table-bordered table-striped">
			<thead>
			<tr>
				<th  scope="col">ID</th>
				<th width="40%" align="left" scope="col">Name</th>
				<th width="30%"  scope="col">Status</th>
				<th  scope="col">Action</th>
			</tr>	
			</thead>
			<?php 
			$i = 1;
			while($row = $result->fetchArray()) {
				?>
			<tr>
			    <td data-label="ID"><?php echo $i;?></td>
				<td data-label="Name"><?php echo $row['name'];?></td>
				<td data-label="Status"><?php echo $row['status'];?></td>
				<td data-label="Action">
					<a class="btn btn-dark" href="?page_action=update&id=<?php echo $row['id'];?>"><i class="fa fa-edit"></i></a> | 
					<a class="btn btn-danger"  href="./delete.php?id=<?php echo $row['id'];?>" onclick="return confirm('Are you sure you want to delete this page?');"><i class="fa fa-trash"></i></a>
				</td>
			</tr>
			<?php 
			$i++;
			} 
			?>
		</table>

  </div>
  
   
  </div>	
</div>	
</div>
<script src="./js/datatablegrid.js"></script>
<script>
$(document).ready( function () {
    var table = $('#pagelist').DataTable();
});
</script>