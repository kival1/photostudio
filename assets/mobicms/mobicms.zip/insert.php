<?php
if (session_status() === PHP_SESSION_NONE){session_start();} 
if(!isset($_SESSION["mobipager"])){
echo "Access Denied";
exit;    
}
$message = ""; // initial message 
if(isset($_POST["add"]) && $_POST["add"] == "yes" ){

	// Includs database connection
	include "db_connect.php";
// Create Table "page" into Database if not exists 
$query = "CREATE TABLE IF NOT EXISTS page (id INTEGER PRIMARY KEY AUTOINCREMENT, status STRING, name STRING, pagetype STRING, title STRING, description STRING, content TEXT)";
$db->exec($query);
	// Gets the data from post
	$status = SQLite3::escapeString(@$_POST['status']);
	$name = SQLite3::escapeString(@$_POST['name']);
	$title = SQLite3::escapeString(@$_POST['title']);
	$description = @$_POST['description'];
	$content = SQLite3::escapeString(@$_POST['content']);

	// Makes query with post data
	$query = "INSERT INTO page (status, name, title, pagetype, description, content) VALUES ('$status', '$name', '$title', 'page',  '$description', '$content')";
	
	// Executes the query
	// If data inserted then set success message otherwise set error message
	// Here $db comes from "db_connection.php"
	if( $db->exec($query) or die($db->lastErrorMsg())){
		$message = "<div class='bg-success text-white'>Page have been added  successfully.</div>";
	}else{
		$message = "<div class='bg-danger text-white'>Sorry, Page was not added.</div>";
	}
}
?>

 <!-- include summernote css/js -->
<link href="summernote/summernote-bs4.min.css?v=1" rel="stylesheet">
<script src="summernote/summernote-bs4.min.js"></script>
<link rel="stylesheet" type="text/css" href="../assets/mobirise/css/mbr-additional.css" />
<!-- Grid editor CSS -->
<link rel="stylesheet" type="text/css" href="./dist/grideditor.css" />
<link rel="stylesheet" type="text/css" href="./css/editor.css" />
	<div class='main-container bg-dark'>
<div class="container-fluid bg-dark pt-2 pb-2">
<div class="modal-content p-3">


<div class="border-bottom row">
<div class="col text-center"><h4><b>Add New Page</b></h4></div>
</div>
<div class="formspec">
<form class="pageform" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING']) ?>" method="post">
<input type="hidden" name="add" value="yes">
<!-- Tabs -->
<section id="tabs">
	<div class="container-fluid">
		<div class="row">
		<div class="col-md-12 p-2 text-center"><?php echo @$message; ?></div>
			<div class="col-md-12 ">
				<nav>
					<div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
						<a class="nav-item nav-link active" id="nav-title-settings-tab" data-toggle="tab" href="#nav-title-settings" role="tab" aria-controls="nav-home" aria-selected="true">Settings</a>
						<a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Meta Tags</a>
						<a class="nav-item nav-link" id="nav-about-tab" data-toggle="tab" href="#nav-about" role="tab" aria-controls="nav-about" aria-selected="false">Page Content</a>
					</div>
				</nav>
				<div class="tab-content py-3 px-3 px-sm-0 col-12 col-md-12 mt-3" id="nav-tabContent" style="width: 100%">
					<div class="tab-pane fade show active" id="nav-title-settings" role="tabpanel" aria-labelledby="nav-home-tab">
					<div class="col-12 col-md-12 col-lg-12">
						<div class="form-group">
						<label>Status</label>
		                 <select name="status" class="form-control custom-select notranslate" required>
						 <option value="">Staus</option>
						 <option value="active">active</option>
						 <option value="disable">disable</option>
						 </select>
                         </div>
						 <div class="form-group">
                            <label>Page Name</label>
                            <input type="text" name="name" required class="form-control notranslate" value="<?php echo empty($name) ? "" : @$name;?>" pattern="[a-zA-Z0-9-_]+">
                        </div>
						</div>
					</div>
					<div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
						<div class="form-group">
                            <label>Title</label>
                            <input type="text" name="title" required class="form-control notranslate" value="<?php echo empty($title) ? $data["title"] : @$title;?>">
                        </div>
						<div class="form-group">
                            <label>Description</label>
                            <textarea id="description" required name="description" id="desc" class="form-control notranslate"><?php echo empty($description) ? "" : @$description;?></textarea>
                        </div>
					</div>
					<div class="tab-pane fade" id="nav-about" role="tabpanel" aria-labelledby="nav-about-tab">
						<div class="form-group">
                            <div class="container-fluid notranslate">
        <div id="myGrid"> </div> <!-- /#myGrid -->
    </div> <!-- /.container -->
	<div class="d-none">
                            <textarea id="bcontent"  name="content" class="form-control myTextarea notranslate"><?php echo empty($content) ? "" : @$content;?></textarea>
		</div>
                        </div>
					</div>
					<div class="modal-footer ">
        <button type="submit" class="btn btn-dark ajaxbtns" ><span class="fa fa-save"></span>&nbsp;&nbsp;Save Page</button>
		 
      </div>
				</div>
			
			</div>
		</div>
	</div>
</section>
<!-- ./Tabs -->

</form>










   
  </div>
  
  </div>	
</div>	
</div>
    <script src="./dist/jquery.grideditor.min.js?v=2"></script>
	<script src="./summernote/plugin/upload/uploadapi.js?v=1"></script>
    <script src="./summernote/plugin/addclass<?php echo @$_SESSION["version"]; ?>.js?v=4"></script>
	<script src="./summernote/plugin/imageatt.js?v=1"></script>
	<script src="./summernote/plugin/custom.js?v=2"></script>
	<script src="./summernote/plugin/table.js?v=4"></script>
	<script src="./summernote/plugin/video.js?v=1"></script>
	<script src="./js/summernote.js?v=1"></script>